// Mobile Menu System - Final Version
class MobileMenu {
    constructor() {
        this.mobileToggle = document.getElementById('nav-toggle');
        this.mobileMenu = document.getElementById('nav-menu');
        this.mobileClose = document.getElementById('mobile-menu-close');
        this.mobileLinks = document.querySelectorAll('.mobile-nav-link');
        this.init();
    }

    init() {
        if (this.mobileToggle && this.mobileMenu) {
            // Toggle mobile menu
            this.mobileToggle.addEventListener('click', (e) => {
                e.preventDefault();
                this.toggleMenu();
            });

            // Close menu with close button
            if (this.mobileClose) {
                this.mobileClose.addEventListener('click', () => {
                    this.closeMenu();
                });
            }

            // Close menu when clicking on links
            this.mobileLinks.forEach(link => {
                link.addEventListener('click', () => {
                    this.closeMenu();
                });
            });

            // Close menu when clicking outside
            document.addEventListener('click', (e) => {
                if (!this.mobileMenu.contains(e.target) && 
                    !this.mobileToggle.contains(e.target) && 
                    this.mobileMenu.classList.contains('active')) {
                    this.closeMenu();
                }
            });

            // Handle escape key
            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.mobileMenu.classList.contains('active')) {
                    this.closeMenu();
                }
            });
        }
    }

    toggleMenu() {
        this.mobileMenu.classList.toggle('active');
        const icon = this.mobileToggle.querySelector('i');
        if (icon) {
            icon.className = this.mobileMenu.classList.contains('active') 
                ? 'fas fa-times' 
                : 'fas fa-bars';
        }
        
        // Toggle body scroll
        document.body.style.overflow = this.mobileMenu.classList.contains('active') 
            ? 'hidden' 
            : '';
    }

    openMenu() {
        this.mobileMenu.classList.add('active');
        const icon = this.mobileToggle.querySelector('i');
        if (icon) {
            icon.className = 'fas fa-times';
        }
        document.body.style.overflow = 'hidden';
    }

    closeMenu() {
        this.mobileMenu.classList.remove('active');
        const icon = this.mobileToggle.querySelector('i');
        if (icon) {
            icon.className = 'fas fa-bars';
        }
        document.body.style.overflow = '';
    }

    // Public method to check if menu is open
    isOpen() {
        return this.mobileMenu.classList.contains('active');
    }
}

// Dropdown Menu Handler
class DropdownMenu {
    constructor() {
        this.dropdowns = document.querySelectorAll('.menu-item.has-dropdown');
        this.init();
    }

    init() {
        this.dropdowns.forEach(dropdown => {
            const toggle = dropdown.querySelector('.dropdown-toggle');
            const menu = dropdown.querySelector('.dropdown-menu');
            
            if (toggle && menu) {
                // Desktop hover
                dropdown.addEventListener('mouseenter', () => {
                    if (window.innerWidth > 768) {
                        this.showDropdown(menu);
                    }
                });
                
                dropdown.addEventListener('mouseleave', () => {
                    if (window.innerWidth > 768) {
                        this.hideDropdown(menu);
                    }
                });
                
                // Mobile click
                toggle.addEventListener('click', (e) => {
                    if (window.innerWidth <= 768) {
                        e.preventDefault();
                        this.toggleDropdown(menu);
                    }
                });
                
                // Touch support
                toggle.addEventListener('touchstart', (e) => {
                    if (window.innerWidth <= 768) {
                        e.preventDefault();
                        this.toggleDropdown(menu);
                    }
                });
            }
        });
        
        // Close dropdowns when clicking elsewhere
        document.addEventListener('click', (e) => {
            if (!e.target.closest('.menu-item.has-dropdown')) {
                this.closeAllDropdowns();
            }
        });
        
        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
    }

    showDropdown(menu) {
        this.closeAllDropdowns();
        menu.style.opacity = '1';
        menu.style.visibility = 'visible';
        menu.style.transform = 'translateY(0)';
    }

    hideDropdown(menu) {
        menu.style.opacity = '0';
        menu.style.visibility = 'hidden';
        menu.style.transform = 'translateY(10px)';
    }

    toggleDropdown(menu) {
        const isVisible = menu.style.visibility === 'visible';
        if (isVisible) {
            this.hideDropdown(menu);
        } else {
            this.showDropdown(menu);
        }
    }

    closeAllDropdowns() {
        document.querySelectorAll('.dropdown-menu').forEach(menu => {
            this.hideDropdown(menu);
        });
    }

    handleResize() {
        if (window.innerWidth > 768) {
            this.closeAllDropdowns();
        }
    }
}

// Theme Switcher
class ThemeSwitcher {
    constructor() {
        this.themeSwitch = document.getElementById('theme-switch');
        this.mobileThemeSwitch = document.getElementById('mobile-theme-switch');
        this.init();
    }

    init() {
        // Set initial theme
        this.setThemeFromStorage();
        
        // Desktop theme switch
        if (this.themeSwitch) {
            this.themeSwitch.addEventListener('click', () => {
                this.toggleTheme();
            });
        }
        
        // Mobile theme switch
        if (this.mobileThemeSwitch) {
            this.mobileThemeSwitch.addEventListener('click', () => {
                this.toggleTheme();
            });
        }
        
        // Listen for system theme changes
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)');
        prefersDark.addEventListener('change', (e) => {
            if (!localStorage.getItem('theme')) {
                this.setTheme(e.matches ? 'dark' : 'light');
            }
        });
    }

    toggleTheme() {
        const currentTheme = document.documentElement.getAttribute('data-theme');
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        this.setTheme(newTheme);
        
        // Update switch icon
        this.updateSwitchIcon(newTheme);
        
        // Show notification
        this.showThemeNotification(newTheme);
    }

    setTheme(theme) {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
    }

    setThemeFromStorage() {
        const savedTheme = localStorage.getItem('theme');
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        
        if (savedTheme) {
            this.setTheme(savedTheme);
        } else if (prefersDark) {
            this.setTheme('dark');
        }
        
        // Update switch icon
        const currentTheme = document.documentElement.getAttribute('data-theme');
        this.updateSwitchIcon(currentTheme);
    }

    updateSwitchIcon(theme) {
        const icon = this.themeSwitch ? this.themeSwitch.querySelector('i') : null;
        const mobileIcon = this.mobileThemeSwitch ? this.mobileThemeSwitch.querySelector('i') : null;
        
        if (icon) {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
        
        if (mobileIcon) {
            mobileIcon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }

    showThemeNotification(theme) {
        if (window.solveSphereApp && window.solveSphereApp.showNotification) {
            window.solveSphereApp.showNotification(
                `Theme changed to ${theme} mode`,
                'info'
            );
        }
    }
}

// Initialize all menu systems
document.addEventListener('DOMContentLoaded', () => {
    window.mobileMenu = new MobileMenu();
    window.dropdownMenu = new DropdownMenu();
    window.themeSwitcher = new ThemeSwitcher();
    
    console.log('Menu systems initialized successfully');
});

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { MobileMenu, DropdownMenu, ThemeSwitcher };
}