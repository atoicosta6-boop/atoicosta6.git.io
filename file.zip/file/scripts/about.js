// About Page JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Custom cursor functionality
    initCustomCursor();
    
    // Set active menu
    setActiveMenu();
    
    // Count up animation
    initCounters();
    
    // Scroll animations
    initScrollAnimations();
    
    // Interactive card effects
    initCardEffects();
    
    // Create floating particles
    createParticles();
    
    // Menu dropdown effects
    initMenuDropdowns();
});

// Custom Cursor
function initCustomCursor() {
    const cursor = document.getElementById('customCursor');
    if (!cursor) return;
    
    let mouseX = 0, mouseY = 0;
    let cursorX = 0, cursorY = 0;
    
    document.addEventListener('mousemove', (e) => {
        mouseX = e.clientX;
        mouseY = e.clientY;
        
        // Create trail effect
        if (Math.random() > 0.7) {
            createCursorTrail(e.clientX, e.clientY);
        }
        
        // Cursor color change on hover
        updateCursorColor(e);
    });
    
    // Smooth cursor movement
    function animateCursor() {
        const dx = mouseX - cursorX;
        const dy = mouseY - cursorY;
        
        cursorX += dx * 0.15;
        cursorY += dy * 0.15;
        
        cursor.style.left = cursorX + 'px';
        cursor.style.top = cursorY + 'px';
        
        requestAnimationFrame(animateCursor);
    }
    animateCursor();
}

function createCursorTrail(x, y) {
    const trail = document.createElement('div');
    trail.className = 'cursor-trail';
    trail.style.left = x + 'px';
    trail.style.top = y + 'px';
    document.body.appendChild(trail);
    
    setTimeout(() => {
        trail.remove();
    }, 500);
}

function updateCursorColor(e) {
    const cursor = document.getElementById('customCursor');
    if (!cursor) return;
    
    const hoverElements = document.querySelectorAll('.nav-link, .btn, .stat-card, .mission-card');
    let isHovering = false;
    
    hoverElements.forEach(el => {
        const rect = el.getBoundingClientRect();
        if (e.clientX >= rect.left && e.clientX <= rect.right &&
            e.clientY >= rect.top && e.clientY <= rect.bottom) {
            isHovering = true;
        }
    });
    
    cursor.style.background = isHovering 
        ? 'radial-gradient(circle, #ff6b6b, #ffa726)'
        : 'radial-gradient(circle, #6c5ce7, #a29bfe)';
}

// Active Menu
function setActiveMenu() {
    const currentPage = 'about.html';
    const navLinks = document.querySelectorAll('.nav-link, .mobile-nav-link');
    
    navLinks.forEach(link => {
        const linkHref = link.getAttribute('href');
        if (linkHref === currentPage) {
            link.classList.add('active');
        } else {
            link.classList.remove('active');
        }
    });
}

// Count Up Animation
function initCounters() {
    const counters = document.querySelectorAll('.count-up');
    if (counters.length === 0) return;
    
    counters.forEach(counter => {
        const target = parseInt(counter.getAttribute('data-counter')) || 0;
        const increment = target / 100;
        let current = 0;
        
        const updateCounter = () => {
            if (current < target) {
                current += increment;
                counter.textContent = Math.ceil(current).toLocaleString();
                setTimeout(updateCounter, 20);
            } else {
                counter.textContent = target.toLocaleString();
            }
        };
        
        // Start counter when in view
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    updateCounter();
                    observer.unobserve(entry.target);
                }
            });
        }, { 
            threshold: 0.5,
            rootMargin: '0px 0px -50px 0px'
        });
        
        observer.observe(counter);
    });
}

// Scroll Animations
function initScrollAnimations() {
    const animateElements = document.querySelectorAll('.animate-on-scroll');
    if (animateElements.length === 0) return;
    
    const scrollObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const delay = parseInt(entry.target.getAttribute('data-delay')) || 0;
                setTimeout(() => {
                    entry.target.classList.add('visible');
                }, delay * 100);
                scrollObserver.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1,
        rootMargin: '0px 0px -100px 0px'
    });
    
    animateElements.forEach(el => scrollObserver.observe(el));
}

// Interactive Card Effects
function initCardEffects() {
    const interactiveCards = document.querySelectorAll('.stat-card, .mission-card');
    
    interactiveCards.forEach(card => {
        // Hover effects
        card.addEventListener('mouseenter', () => {
            card.style.transform = 'translateY(-20px) scale(1.05)';
            card.style.boxShadow = '0 40px 80px rgba(108, 92, 231, 0.3)';
        });
        
        card.addEventListener('mouseleave', () => {
            card.style.transform = '';
            card.style.boxShadow = '';
        });
        
        // Click effect
        card.addEventListener('click', (e) => {
            const cardElement = e.currentTarget;
            
            // Reset animation
            cardElement.style.animation = 'none';
            setTimeout(() => {
                cardElement.style.animation = '';
            }, 10);
            
            // Create ripple effect
            createRippleEffect(cardElement, e);
        });
    });
}

function createRippleEffect(element, event) {
    const ripple = document.createElement('div');
    const rect = element.getBoundingClientRect();
    const size = Math.max(rect.width, rect.height);
    
    ripple.style.width = ripple.style.height = size + 'px';
    ripple.style.left = event.clientX - rect.left - size/2 + 'px';
    ripple.style.top = event.clientY - rect.top - size/2 + 'px';
    ripple.style.position = 'absolute';
    ripple.style.borderRadius = '50%';
    ripple.style.background = 'rgba(108, 92, 231, 0.2)';
    ripple.style.transform = 'scale(0)';
    ripple.style.animation = 'ripple 0.6s linear';
    ripple.style.pointerEvents = 'none';
    
    element.style.position = 'relative';
    element.style.overflow = 'hidden';
    element.appendChild(ripple);
    
    setTimeout(() => {
        ripple.remove();
    }, 600);
}

// Floating Particles
function createParticles() {
    const container = document.querySelector('.floating-elements');
    if (!container) return;
    
    // Remove default particles to avoid duplicates
    const existingParticles = container.querySelectorAll('.floating-element');
    existingParticles.forEach((particle, index) => {
        if (index > 3) particle.remove();
    });
    
    // Add more particles
    for (let i = 0; i < 15; i++) {
        const particle = document.createElement('div');
        particle.className = 'floating-element';
        particle.style.width = Math.random() * 80 + 40 + 'px';
        particle.style.height = particle.style.width;
        particle.style.top = Math.random() * 100 + '%';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.background = `linear-gradient(135deg, 
            rgba(${Math.random() * 100 + 156}, ${Math.random() * 100 + 92}, ${Math.random() * 100 + 231}, ${Math.random() * 0.1 + 0.05}), 
            rgba(${Math.random() * 100 + 162}, ${Math.random() * 100 + 155}, ${Math.random() * 100 + 254}, ${Math.random() * 0.1 + 0.05}))`;
        particle.style.animationDelay = Math.random() * 20 + 's';
        particle.style.animationDuration = Math.random() * 10 + 15 + 's';
        particle.style.borderRadius = `${Math.random() * 50}% ${Math.random() * 50}% ${Math.random() * 50}% ${Math.random() * 50}% / ${Math.random() * 50}% ${Math.random() * 50}% ${Math.random() * 50}% ${Math.random() * 50}%`;
        
        container.appendChild(particle);
    }
}

// Menu Dropdown Effects
function initMenuDropdowns() {
    const dropdowns = document.querySelectorAll('.dropdown');
    
    dropdowns.forEach(dropdown => {
        dropdown.addEventListener('mouseenter', () => {
            const content = dropdown.querySelector('.dropdown-content');
            if (content) {
                content.style.display = 'block';
                setTimeout(() => {
                    content.style.opacity = '1';
                    content.style.visibility = 'visible';
                    content.style.transform = 'translateY(0) scale(1)';
                }, 10);
            }
        });
        
        dropdown.addEventListener('mouseleave', () => {
            const content = dropdown.querySelector('.dropdown-content');
            if (content) {
                content.style.opacity = '0';
                content.style.visibility = 'hidden';
                content.style.transform = 'translateY(20px) scale(0.95)';
                setTimeout(() => {
                    content.style.display = 'none';
                }, 400);
            }
        });
    });
}

// Expose functions to global scope
window.createRippleEffect = createRippleEffect;