// Advanced Animation System
class AnimationSystem {
    constructor() {
        this.animations = new Map();
        this.reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
        this.scrollY = 0;
        this.activeAnimations = new Set();
        this.init();
    }

    init() {
        this.setupScrollAnimations();
        this.setupHoverAnimations();
        this.setupClickAnimations();
        this.setupTypewriter();
        this.setupCounters();
        this.setupProgressBars();
        this.setupParallax();
        this.setupParticles();
        this.setupPageTransitions();
        this.setupIntersectionObserver();
        this.setupResizeHandler();
        
        // Add animation styles
        this.addAnimationStyles();
    }

    // Add CSS animation styles
    addAnimationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .ripple {
                position: absolute;
                border-radius: 50%;
                background: rgba(255, 255, 255, 0.6);
                transform: scale(0);
                animation: ripple 0.6s linear;
                pointer-events: none;
            }
            
            @keyframes ripple {
                to {
                    transform: scale(4);
                    opacity: 0;
                }
            }
            
            .page-transition {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: var(--primary-color);
                z-index: 9999;
                transform: scaleX(0);
                transform-origin: left;
            }
            
            .page-transition.active {
                animation: pageTransition 0.5s ease-out forwards;
            }
            
            @keyframes pageTransition {
                to {
                    transform: scaleX(1);
                }
            }
            
            .typewriter-cursor {
                display: inline-block;
                width: 3px;
                background: var(--primary-color);
                margin-left: 2px;
                animation: blink 0.7s infinite;
            }
            
            @keyframes blink {
                0%, 100% { opacity: 1; }
                50% { opacity: 0; }
            }
            
            .floating {
                animation: float 6s ease-in-out infinite;
            }
            
            .pulse {
                animation: pulse 2s infinite;
            }
            
            .bounce {
                animation: bounce 2s infinite;
            }
            
            .spin {
                animation: spin 1s linear infinite;
            }
            
            .fade-in {
                animation: fadeIn 0.5s ease-out;
            }
            
            .fade-in-up {
                animation: fadeInUp 0.5s ease-out;
            }
            
            .fade-in-down {
                animation: fadeInDown 0.5s ease-out;
            }
            
            .fade-in-left {
                animation: fadeInLeft 0.5s ease-out;
            }
            
            .fade-in-right {
                animation: fadeInRight 0.5s ease-out;
            }
            
            .slide-in-right {
                animation: slideInRight 0.3s ease-out;
            }
            
            .slide-in-left {
                animation: slideInLeft 0.3s ease-out;
            }
            
            .zoom-in {
                animation: zoomIn 0.5s ease-out;
            }
            
            .rotate-in {
                animation: rotateIn 0.5s ease-out;
            }
            
            @keyframes float {
                0%, 100% { transform: translateY(0px); }
                50% { transform: translateY(-20px); }
            }
            
            @keyframes pulse {
                0%, 100% { transform: scale(1); }
                50% { transform: scale(1.05); }
            }
            
            @keyframes bounce {
                0%, 100% { transform: translateY(0); }
                50% { transform: translateY(-10px); }
            }
            
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
            
            @keyframes fadeIn {
                from { opacity: 0; }
                to { opacity: 1; }
            }
            
            @keyframes fadeInUp {
                from {
                    opacity: 0;
                    transform: translateY(20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes fadeInDown {
                from {
                    opacity: 0;
                    transform: translateY(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes fadeInLeft {
                from {
                    opacity: 0;
                    transform: translateX(-20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            @keyframes fadeInRight {
                from {
                    opacity: 0;
                    transform: translateX(20px);
                }
                to {
                    opacity: 1;
                    transform: translateX(0);
                }
            }
            
            @keyframes slideInRight {
                from { transform: translateX(100%); }
                to { transform: translateX(0); }
            }
            
            @keyframes slideInLeft {
                from { transform: translateX(-100%); }
                to { transform: translateX(0); }
            }
            
            @keyframes zoomIn {
                from {
                    transform: scale(0.8);
                    opacity: 0;
                }
                to {
                    transform: scale(1);
                    opacity: 1;
                }
            }
            
            @keyframes rotateIn {
                from {
                    transform: rotate(-180deg) scale(0.5);
                    opacity: 0;
                }
                to {
                    transform: rotate(0) scale(1);
                    opacity: 1;
                }
            }
            
            .stagger-item {
                opacity: 0;
                animation: fadeInUp 0.5s ease-out forwards;
            }
            
            @keyframes particle-float {
                0% {
                    transform: translateY(0) rotate(0deg);
                    opacity: 0.5;
                }
                100% {
                    transform: translateY(-1000px) rotate(720deg);
                    opacity: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    // Setup scroll-based animations
    setupScrollAnimations() {
        if (this.reducedMotion) return;

        const scrollElements = document.querySelectorAll('[data-scroll-animate]');
        
        scrollElements.forEach(element => {
            const animation = element.dataset.scrollAnimate || 'fade-in-up';
            const threshold = element.dataset.scrollThreshold || 0.3;
            
            this.animations.set(element, {
                type: 'scroll',
                animation: animation,
                threshold: parseFloat(threshold),
                animated: false
            });
        });

        // Initial check
        this.checkScrollAnimations();
        
        // Scroll listener with throttle
        let ticking = false;
        window.addEventListener('scroll', () => {
            this.scrollY = window.scrollY;
            
            if (!ticking) {
                window.requestAnimationFrame(() => {
                    this.checkScrollAnimations();
                    ticking = false;
                });
                ticking = true;
            }
        });
    }

    checkScrollAnimations() {
        const windowHeight = window.innerHeight;
        const scrollPosition = this.scrollY + windowHeight;
        
        this.animations.forEach((data, element) => {
            if (data.type === 'scroll' && !data.animated) {
                const elementPosition = element.offsetTop;
                const elementHeight = element.offsetHeight;
                
                if (scrollPosition > elementPosition + (elementHeight * data.threshold)) {
                    this.animate(element, data.animation);
                    data.animated = true;
                }
            }
        });
    }

    // Setup hover animations
    setupHoverAnimations() {
        const hoverElements = document.querySelectorAll('[data-hover-animate]');
        
        hoverElements.forEach(element => {
            const animation = element.dataset.hoverAnimate || 'scale';
            
            element.addEventListener('mouseenter', () => {
                this.animateHover(element, animation, 'enter');
            });
            
            element.addEventListener('mouseleave', () => {
                this.animateHover(element, animation, 'leave');
            });
        });
    }

    animateHover(element, animation, state) {
        if (this.reducedMotion) return;
        
        switch(animation) {
            case 'scale':
                element.style.transform = state === 'enter' ? 'scale(1.05)' : 'scale(1)';
                break;
            case 'lift':
                element.style.transform = state === 'enter' ? 'translateY(-10px)' : 'translateY(0)';
                break;
            case 'rotate':
                element.style.transform = state === 'enter' ? 'rotate(5deg)' : 'rotate(0)';
                break;
            case 'glow':
                element.style.boxShadow = state === 'enter' 
                    ? '0 0 20px rgba(99, 102, 241, 0.5)' 
                    : '';
                break;
            case 'color':
                element.style.backgroundColor = state === 'enter' 
                    ? 'rgba(99, 102, 241, 0.1)' 
                    : '';
                break;
        }
        
        element.style.transition = 'all 0.3s ease';
    }

    // Setup click animations
    setupClickAnimations() {
        const clickElements = document.querySelectorAll('[data-click-animate]');
        
        clickElements.forEach(element => {
            element.addEventListener('click', (e) => {
                const animation = element.dataset.clickAnimate || 'ripple';
                this.animateClick(element, animation, e);
            });
        });

        // Add ripple effect to all buttons
        const buttons = document.querySelectorAll('.btn');
        buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                this.createRipple(e, button);
            });
        });
    }

    animateClick(element, animation, event) {
        if (this.reducedMotion) return;
        
        switch(animation) {
            case 'bounce':
                element.classList.add('bounce');
                setTimeout(() => element.classList.remove('bounce'), 1000);
                break;
            case 'shake':
                element.classList.add('shake');
                setTimeout(() => element.classList.remove('shake'), 500);
                break;
            case 'pulse':
                element.classList.add('pulse');
                setTimeout(() => element.classList.remove('pulse'), 1000);
                break;
            case 'ripple':
                this.createRipple(event, element);
                break;
            case 'flip':
                element.classList.add('flip-card');
                setTimeout(() => element.classList.remove('flip-card'), 600);
                break;
        }
    }

    createRipple(event, element) {
        const ripple = document.createElement('span');
        const rect = element.getBoundingClientRect();
        
        const size = Math.max(rect.width, rect.height);
        const x = event.clientX - rect.left - size / 2;
        const y = event.clientY - rect.top - size / 2;
        
        ripple.style.width = ripple.style.height = `${size}px`;
        ripple.style.left = `${x}px`;
        ripple.style.top = `${y}px`;
        ripple.classList.add('ripple');
        
        element.appendChild(ripple);
        
        setTimeout(() => {
            ripple.remove();
        }, 600);
    }

    // Setup typewriter effect
    setupTypewriter() {
        const typewriterElements = document.querySelectorAll('[data-typewriter]');
        
        typewriterElements.forEach(element => {
            const texts = element.dataset.typewriter.split('|');
            const speed = parseInt(element.dataset.typeSpeed) || 100;
            const delay = parseInt(element.dataset.typeDelay) || 2000;
            
            this.startTypewriter(element, texts, speed, delay);
        });
    }

    startTypewriter(element, texts, speed, delay) {
        let textIndex = 0;
        let charIndex = 0;
        let isDeleting = false;
        let isWaiting = false;
        
        function type() {
            if (isWaiting) return;
            
            const currentText = texts[textIndex];
            
            if (isDeleting) {
                element.textContent = currentText.substring(0, charIndex - 1);
                charIndex--;
            } else {
                element.textContent = currentText.substring(0, charIndex + 1);
                charIndex++;
            }
            
            if (!isDeleting && charIndex === currentText.length) {
                isDeleting = true;
                isWaiting = true;
                setTimeout(() => {
                    isWaiting = false;
                    setTimeout(type, delay);
                }, delay);
            } else if (isDeleting && charIndex === 0) {
                isDeleting = false;
                textIndex = (textIndex + 1) % texts.length;
                setTimeout(type, 500);
            } else {
                setTimeout(type, isDeleting ? speed / 2 : speed);
            }
        }
        
        // Add cursor
        const cursor = document.createElement('span');
        cursor.className = 'typewriter-cursor';
        element.parentNode.appendChild(cursor);
        
        // Start typing after a short delay
        setTimeout(type, 1000);
    }

    // Setup counter animations
    setupCounters() {
        const counterElements = document.querySelectorAll('[data-counter]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateCounter(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        counterElements.forEach(element => {
            observer.observe(element);
        });
    }

    animateCounter(element) {
        const target = parseInt(element.dataset.counter) || 100;
        const duration = parseInt(element.dataset.counterDuration) || 2000;
        const suffix = element.dataset.counterSuffix || '';
        const prefix = element.dataset.counterPrefix || '';
        const format = element.dataset.counterFormat || 'integer';
        
        let start = 0;
        const increment = target / (duration / 16);
        
        const timer = setInterval(() => {
            start += increment;
            if (start >= target) {
                start = target;
                clearInterval(timer);
            }
            
            if (format === 'decimal') {
                element.textContent = `${prefix}${start.toFixed(1)}${suffix}`;
            } else if (format === 'currency') {
                element.textContent = `${prefix}${Math.floor(start).toLocaleString()}${suffix}`;
            } else {
                element.textContent = `${prefix}${Math.floor(start)}${suffix}`;
            }
        }, 16);
    }

    // Setup progress bar animations
    setupProgressBars() {
        const progressBars = document.querySelectorAll('[data-progress]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    this.animateProgressBar(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });
        
        progressBars.forEach(bar => {
            observer.observe(bar);
        });
    }

    animateProgressBar(progressBar) {
        const target = parseInt(progressBar.dataset.progress) || 100;
        const duration = parseInt(progressBar.dataset.progressDuration) || 2000;
        
        let width = 0;
        const increment = target / (duration / 16);
        
        const timer = setInterval(() => {
            width += increment;
            if (width >= target) {
                width = target;
                clearInterval(timer);
            }
            
            progressBar.style.width = `${width}%`;
        }, 16);
    }

    // Setup parallax effects
    setupParallax() {
        if (this.reducedMotion) return;

        const parallaxElements = document.querySelectorAll('[data-parallax]');
        
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            
            parallaxElements.forEach(element => {
                const speed = parseFloat(element.dataset.parallax) || 0.5;
                const yPos = -(scrolled * speed);
                element.style.transform = `translateY(${yPos}px)`;
            });
        });
    }

    // Setup particle systems
    setupParticles() {
        const particleContainers = document.querySelectorAll('.particles-container');
        
        particleContainers.forEach(container => {
            this.createParticles(container);
        });
    }

    createParticles(container) {
        const count = parseInt(container.dataset.particleCount) || 50;
        const colors = container.dataset.particleColors?.split(',') || ['#6366f1', '#10b981', '#f59e0b'];
        
        for (let i = 0; i < count; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Random properties
            const size = Math.random() * 5 + 1;
            const posX = Math.random() * 100;
            const posY = Math.random() * 100;
            const color = colors[Math.floor(Math.random() * colors.length)];
            const duration = Math.random() * 20 + 10;
            const delay = Math.random() * 5;
            
            particle.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                background: ${color};
                border-radius: 50%;
                left: ${posX}%;
                top: ${posY}%;
                opacity: ${Math.random() * 0.5 + 0.1};
                animation: particle-float ${duration}s linear infinite;
                animation-delay: ${delay}s;
            `;
            
            container.appendChild(particle);
        }
    }

    // Setup page transitions
    setupPageTransitions() {
        const links = document.querySelectorAll('a[href]:not([href^="#"])');
        
        links.forEach(link => {
            link.addEventListener('click', (e) => {
                if (link.href && !link.target && link.href !== window.location.href) {
                    e.preventDefault();
                    this.startPageTransition(link.href);
                }
            });
        });
    }

    startPageTransition(url) {
        const overlay = document.createElement('div');
        overlay.className = 'page-transition';
        document.body.appendChild(overlay);
        
        // Animate overlay
        setTimeout(() => {
            overlay.classList.add('active');
        }, 10);
        
        setTimeout(() => {
            window.location.href = url;
        }, 500);
    }

    // Setup intersection observer for animations
    setupIntersectionObserver() {
        const animatedElements = document.querySelectorAll('[data-animate]');
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const animation = entry.target.dataset.animate || 'fade-in-up';
                    const delay = entry.target.dataset.animateDelay || 0;
                    
                    setTimeout(() => {
                        this.animate(entry.target, animation);
                    }, parseInt(delay));
                    
                    observer.unobserve(entry.target);
                }
            });
        }, {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        });
        
        animatedElements.forEach(element => {
            observer.observe(element);
        });
    }

    // Setup resize handler
    setupResizeHandler() {
        window.addEventListener('resize', () => {
            // Update animations on resize
            this.handleResize();
        });
    }

    handleResize() {
        // Update parallax on resize
        this.setupParallax();
    }

    // Core animation method
    animate(element, animation) {
        if (this.reducedMotion) {
            element.classList.add('fade-in');
            return;
        }
        
        element.classList.add(animation);
        this.activeAnimations.add(element);
        
        // Remove animation class after it completes
        const duration = this.getAnimationDuration(element);
        setTimeout(() => {
            element.classList.remove(animation);
            this.activeAnimations.delete(element);
        }, duration);
    }

    getAnimationDuration(element) {
        const style = getComputedStyle(element);
        const duration = parseFloat(style.animationDuration) * 1000 || 1000;
        return duration;
    }

    // Public methods
    playAnimation(elementId, animationName) {
        const element = document.getElementById(elementId);
        if (element) {
            this.animate(element, animationName);
        }
    }

    stopAnimation(elementId) {
        const element = document.getElementById(elementId);
        if (element) {
            const animations = element.getAnimations();
            animations.forEach(animation => {
                animation.cancel();
            });
            this.activeAnimations.delete(element);
        }
    }

    // NEW: Stop all animations
    stopAllAnimations() {
        // Stop all CSS animations
        this.activeAnimations.forEach(element => {
            const animations = element.getAnimations();
            animations.forEach(animation => {
                animation.cancel();
            });
            element.classList.remove('fade-in', 'fade-in-up', 'fade-in-down', 'fade-in-left', 'fade-in-right', 
                                   'zoom-in', 'rotate-in', 'slide-in-right', 'slide-in-left', 'pulse', 
                                   'bounce', 'spin', 'floating');
        });
        this.activeAnimations.clear();
        
        // Stop counter animations
        document.querySelectorAll('[data-counter]').forEach(counter => {
            const target = counter.dataset.counter || '0';
            const suffix = counter.dataset.counterSuffix || '';
            const prefix = counter.dataset.counterPrefix || '';
            counter.textContent = `${prefix}${target}${suffix}`;
        });
        
        // Stop progress bars
        document.querySelectorAll('[data-progress]').forEach(progressBar => {
            const progress = progressBar.dataset.progress || '100';
            progressBar.style.width = `${progress}%`;
        });
        
        // Stop typewriter
        document.querySelectorAll('.typewriter-cursor').forEach(cursor => {
            cursor.remove();
        });
        
        // Stop particles
        document.querySelectorAll('.particle').forEach(particle => {
            particle.style.animation = 'none';
        });
        
        console.log('All animations stopped');
    }

    createConfetti(options = {}) {
        const config = {
            count: options.count || 100,
            colors: options.colors || ['#6366f1', '#10b981', '#f59e0b', '#ef4444'],
            spread: options.spread || 100,
            duration: options.duration || 3000
        };
        
        const container = document.createElement('div');
        container.className = 'confetti-container';
        container.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            pointer-events: none;
            z-index: 10000;
        `;
        
        document.body.appendChild(container);
        
        for (let i = 0; i < config.count; i++) {
            const confetti = document.createElement('div');
            confetti.className = 'confetti';
            
            const size = Math.random() * 10 + 5;
            const color = config.colors[Math.floor(Math.random() * config.colors.length)];
            const startX = Math.random() * 100;
            const rotation = Math.random() * 720 - 360;
            
            confetti.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                background: ${color};
                top: -20px;
                left: ${startX}%;
                border-radius: ${Math.random() > 0.5 ? '50%' : '0'};
                animation: particle-float ${config.duration}ms linear forwards;
                animation-delay: ${Math.random() * 1000}ms;
                transform: rotate(${rotation}deg);
            `;
            
            container.appendChild(confetti);
        }
        
        setTimeout(() => {
            container.remove();
        }, config.duration + 1000);
    }

    createStaggerAnimation(containerSelector, animation = 'fade-in-up') {
        const container = document.querySelector(containerSelector);
        if (!container) return;
        
        const children = container.children;
        Array.from(children).forEach((child, index) => {
            child.classList.add('stagger-item');
            child.style.animationDelay = `${index * 0.1}s`;
            child.style.animationName = animation.replace('fade-in-', '');
        });
    }

    // Wave animation
    createWave(elementId) {
        const element = document.getElementById(elementId);
        if (!element) return;
        
        const wave = document.createElement('div');
        wave.className = 'wave-animation';
        wave.style.cssText = `
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border-radius: inherit;
            background: rgba(255, 255, 255, 0.3);
            transform: scale(0);
            animation: waveExpand 1s ease-out;
        `;
        
        element.appendChild(wave);
        
        setTimeout(() => {
            wave.remove();
        }, 1000);
    }
}

// Initialize Animation System
document.addEventListener('DOMContentLoaded', () => {
    window.animationSystem = new AnimationSystem();
    
    // Add wave animation keyframes
    const waveStyle = document.createElement('style');
    waveStyle.textContent = `
        @keyframes waveExpand {
            to {
                transform: scale(2);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(waveStyle);
});