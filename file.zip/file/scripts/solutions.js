// Solutions Data and Functionality
document.addEventListener('DOMContentLoaded', function() {
    // Load solutions data
    loadSolutions();
    
    // Tab functionality
    const tabBtns = document.querySelectorAll('.tab-btn');
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Remove active class from all buttons
            tabBtns.forEach(b => b.classList.remove('active'));
            
            // Add active class to clicked button
            this.classList.add('active');
            
            // Filter solutions
            const tab = this.dataset.tab;
            filterSolutions(tab);
        });
    });
    
    // Add to cart functionality
    document.addEventListener('click', function(e) {
        if (e.target.closest('.btn-primary') && e.target.closest('.solution-card')) {
            const card = e.target.closest('.solution-card');
            const title = card.querySelector('.solution-title').textContent;
            const price = card.querySelector('.solution-price').textContent;
            
            alert(`Added to cart: ${title} - ${price}`);
            // Here you would typically add to cart functionality
        }
    });
});

function filterSolutions(category) {
    const cards = document.querySelectorAll('.solution-card');
    cards.forEach(card => {
        if (category === 'all' || card.dataset.category === category) {
            card.style.display = 'block';
            card.style.animation = 'fadeIn 0.5s ease';
        } else {
            card.style.display = 'none';
        }
    });
}

function loadSolutions() {
    const solutions = [
        {
            id: 1,
            title: "AI Predictive Analytics",
            category: "ai",
            icon: "fa-chart-line",
            description: "Sistem prediksi berbasis machine learning untuk analisis tren dan peramalan bisnis dengan akurasi tinggi.",
            features: ["95% Accuracy", "Real-time Processing", "Custom Models", "API Integration"],
            price: "Rp 5.000.000"
        },
        {
            id: 2,
            title: "Web Security Suite",
            category: "security",
            icon: "fa-shield-alt",
            description: "Paket keamanan lengkap untuk website dengan monitoring 24/7 dan proteksi maksimal.",
            features: ["DDoS Protection", "Malware Scan", "SSL Certificate", "Firewall"],
            price: "Rp 3.500.000"
        },
        {
            id: 3,
            title: "Cloud Migration",
            category: "web",
            icon: "fa-cloud-upload-alt",
            description: "Migrasi sistem ke cloud dengan zero downtime dan optimasi performa.",
            features: ["AWS/Azure/GCP", "Auto Scaling", "Disaster Recovery", "Backup"],
            price: "Rp 8.000.000"
        },
        {
            id: 4,
            title: "Chatbot AI",
            category: "ai",
            icon: "fa-robot",
            description: "Chatbot cerdas dengan kemampuan NLP untuk meningkatkan customer service.",
            features: ["Natural Language", "Multi-language", "CRM Integration", "24/7 Support"],
            price: "Rp 6.500.000"
        },
        {
            id: 5,
            title: "E-commerce Platform",
            category: "web",
            icon: "fa-shopping-cart",
            description: "Platform e-commerce lengkap dengan payment gateway dan dashboard analytics.",
            features: ["Mobile Responsive", "Payment Gateway", "Inventory Management", "Analytics"],
            price: "Rp 12.000.000"
        },
        {
            id: 6,
            title: "Cybersecurity Audit",
            category: "security",
            icon: "fa-user-shield",
            description: "Audit keamanan menyeluruh untuk sistem dan aplikasi Anda.",
            features: ["Vulnerability Scan", "Penetration Test", "Security Report", "Consultation"],
            price: "Rp 7.500.000"
        }
    ];

    renderSolutions(solutions);
}

function renderSolutions(solutions) {
    const container = document.getElementById('solutions-grid');
    if (!container) return;

    container.innerHTML = solutions.map(solution => `
        <div class="solution-card hover-lift" data-animate="fade-in-up" data-category="${solution.category}">
            <div class="solution-icon">
                <i class="fas ${solution.icon}"></i>
            </div>
            <span class="solution-category">${solution.category.toUpperCase()}</span>
            <h3 class="solution-title">${solution.title}</h3>
            <p class="solution-desc">${solution.description}</p>
            
            <div class="solution-features">
                ${solution.features.map(feature => `
                    <span class="feature-tag">${feature}</span>
                `).join('')}
            </div>
            
            <div class="solution-footer">
                <div class="solution-price">${solution.price}</div>
                <button class="btn btn-primary" data-click-animate="ripple">
                    <i class="fas fa-shopping-cart"></i>
                    Get Solution
                </button>
            </div>
        </div>
    `).join('');
}