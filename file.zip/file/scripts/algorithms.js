// ===========================================
// SOLVESPHERE - ALGORITHMS IMPLEMENTATION
// BFS, DFS, A*, Dijkstra and other algorithms
// ===========================================

class Graph {
    constructor() {
        this.nodes = new Map();
        this.edges = new Map();
    }
    
    addNode(id, data = {}) {
        this.nodes.set(id, {
            id,
            ...data,
            neighbors: new Set()
        });
        return this.nodes.get(id);
    }
    
    addEdge(from, to, weight = 1) {
        if (!this.nodes.has(from) || !this.nodes.has(to)) {
            throw new Error('Node not found');
        }
        
        const edgeId = `${from}-${to}`;
        this.edges.set(edgeId, { from, to, weight });
        
        this.nodes.get(from).neighbors.add(to);
        this.nodes.get(to).neighbors.add(from);
        
        return this.edges.get(edgeId);
    }
    
    getNode(id) {
        return this.nodes.get(id);
    }
    
    getNeighbors(id) {
        const node = this.nodes.get(id);
        return node ? Array.from(node.neighbors) : [];
    }
    
    getAllNodes() {
        return Array.from(this.nodes.values());
    }
    
    getAllEdges() {
        return Array.from(this.edges.values());
    }
    
    generateGrid(rows, cols) {
        const grid = [];
        let nodeId = 0;
        
        for (let i = 0; i < rows; i++) {
            const row = [];
            for (let j = 0; j < cols; j++) {
                const node = this.addNode(nodeId.toString(), {
                    row: i,
                    col: j,
                    type: 'empty'
                });
                row.push(node);
                nodeId++;
            }
            grid.push(row);
        }
        
        // Add edges
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < cols; j++) {
                const currentId = grid[i][j].id;
                
                // Right
                if (j < cols - 1) {
                    this.addEdge(currentId, grid[i][j + 1].id);
                }
                
                // Down
                if (i < rows - 1) {
                    this.addEdge(currentId, grid[i + 1][j].id);
                }
                
                // Diagonal (optional)
                // if (i < rows - 1 && j < cols - 1) {
                //     this.addEdge(currentId, grid[i + 1][j + 1].id, Math.sqrt(2));
                // }
            }
        }
        
        return grid;
    }
}

class AlgorithmVisualizer {
    constructor() {
        this.graph = new Graph();
        this.currentAlgorithm = 'bfs';
        this.visualizationSpeed = 5;
        this.isRunning = false;
        this.animationSteps = [];
        this.currentStep = 0;
        this.callbacks = {
            onNodeVisit: null,
            onPathFound: null,
            onComplete: null
        };
    }
    
    // Breadth-First Search
    bfs(startId, endId) {
        const queue = [{ id: startId, path: [startId] }];
        const visited = new Set([startId]);
        const steps = [];
        
        while (queue.length > 0 && !this.isRunning) {
            const { id: currentId, path } = queue.shift();
            
            steps.push({
                type: 'visit',
                nodeId: currentId,
                path: [...path]
            });
            
            if (currentId === endId) {
                steps.push({
                    type: 'found',
                    path: path,
                    visited: Array.from(visited)
                });
                return steps;
            }
            
            const neighbors = this.graph.getNeighbors(currentId);
            
            for (const neighborId of neighbors) {
                if (!visited.has(neighborId)) {
                    visited.add(neighborId);
                    queue.push({
                        id: neighborId,
                        path: [...path, neighborId]
                    });
                    
                    steps.push({
                        type: 'discover',
                        nodeId: neighborId,
                        from: currentId
                    });
                }
            }
        }
        
        steps.push({
            type: 'not_found',
            visited: Array.from(visited)
        });
        
        return steps;
    }
    
    // Depth-First Search
    dfs(startId, endId) {
        const stack = [{ id: startId, path: [startId] }];
        const visited = new Set([startId]);
        const steps = [];
        
        while (stack.length > 0 && !this.isRunning) {
            const { id: currentId, path } = stack.pop();
            
            steps.push({
                type: 'visit',
                nodeId: currentId,
                path: [...path]
            });
            
            if (currentId === endId) {
                steps.push({
                    type: 'found',
                    path: path,
                    visited: Array.from(visited)
                });
                return steps;
            }
            
            const neighbors = this.graph.getNeighbors(currentId);
            
            for (const neighborId of neighbors) {
                if (!visited.has(neighborId)) {
                    visited.add(neighborId);
                    stack.push({
                        id: neighborId,
                        path: [...path, neighborId]
                    });
                    
                    steps.push({
                        type: 'discover',
                        nodeId: neighborId,
                        from: currentId
                    });
                }
            }
        }
        
        steps.push({
            type: 'not_found',
            visited: Array.from(visited)
        });
        
        return steps;
    }
    
    // A* Search Algorithm
    aStar(startId, endId, heuristic = this.manhattanDistance) {
        const openSet = new Set([startId]);
        const cameFrom = new Map();
        const gScore = new Map();
        const fScore = new Map();
        
        const startNode = this.graph.getNode(startId);
        const endNode = this.graph.getNode(endId);
        
        gScore.set(startId, 0);
        fScore.set(startId, heuristic(startNode, endNode));
        
        const steps = [];
        
        while (openSet.size > 0 && !this.isRunning) {
            // Get node with lowest fScore
            let currentId = null;
            let lowestFScore = Infinity;
            
            for (const nodeId of openSet) {
                const score = fScore.get(nodeId) || Infinity;
                if (score < lowestFScore) {
                    lowestFScore = score;
                    currentId = nodeId;
                }
            }
            
            steps.push({
                type: 'visit',
                nodeId: currentId
            });
            
            if (currentId === endId) {
                const path = this.reconstructPath(cameFrom, currentId);
                steps.push({
                    type: 'found',
                    path: path
                });
                return steps;
            }
            
            openSet.delete(currentId);
            
            const neighbors = this.graph.getNeighbors(currentId);
            
            for (const neighborId of neighbors) {
                const currentGScore = gScore.get(currentId) || Infinity;
                const edge = this.graph.edges.get(`${currentId}-${neighborId}`) || 
                            this.graph.edges.get(`${neighborId}-${currentId}`);
                const tentativeGScore = currentGScore + (edge ? edge.weight : 1);
                
                if (tentativeGScore < (gScore.get(neighborId) || Infinity)) {
                    cameFrom.set(neighborId, currentId);
                    gScore.set(neighborId, tentativeGScore);
                    
                    const neighborNode = this.graph.getNode(neighborId);
                    fScore.set(neighborId, tentativeGScore + heuristic(neighborNode, endNode));
                    
                    if (!openSet.has(neighborId)) {
                        openSet.add(neighborId);
                        steps.push({
                            type: 'discover',
                            nodeId: neighborId,
                            from: currentId
                        });
                    }
                }
            }
        }
        
        steps.push({
            type: 'not_found'
        });
        
        return steps;
    }
    
    // Dijkstra's Algorithm
    dijkstra(startId, endId) {
        const distances = new Map();
        const previous = new Map();
        const unvisited = new Set();
        
        const nodes = this.graph.getAllNodes();
        
        nodes.forEach(node => {
            distances.set(node.id, Infinity);
            previous.set(node.id, null);
            unvisited.add(node.id);
        });
        
        distances.set(startId, 0);
        
        const steps = [];
        
        while (unvisited.size > 0 && !this.isRunning) {
            // Get unvisited node with smallest distance
            let currentId = null;
            let smallestDistance = Infinity;
            
            for (const nodeId of unvisited) {
                const distance = distances.get(nodeId);
                if (distance < smallestDistance) {
                    smallestDistance = distance;
                    currentId = nodeId;
                }
            }
            
            if (currentId === null) break;
            
            steps.push({
                type: 'visit',
                nodeId: currentId
            });
            
            if (currentId === endId) {
                const path = this.reconstructPath(previous, currentId);
                steps.push({
                    type: 'found',
                    path: path,
                    distance: smallestDistance
                });
                return steps;
            }
            
            unvisited.delete(currentId);
            
            const neighbors = this.graph.getNeighbors(currentId);
            
            for (const neighborId of neighbors) {
                if (unvisited.has(neighborId)) {
                    const edge = this.graph.edges.get(`${currentId}-${neighborId}`) || 
                                this.graph.edges.get(`${neighborId}-${currentId}`);
                    const alt = distances.get(currentId) + (edge ? edge.weight : 1);
                    
                    if (alt < distances.get(neighborId)) {
                        distances.set(neighborId, alt);
                        previous.set(neighborId, currentId);
                        
                        steps.push({
                            type: 'update',
                            nodeId: neighborId,
                            distance: alt,
                            from: currentId
                        });
                    }
                }
            }
        }
        
        steps.push({
            type: 'not_found'
        });
        
        return steps;
    }
    
    // Helper methods
    manhattanDistance(nodeA, nodeB) {
        if (!nodeA || !nodeB) return 0;
        const dx = Math.abs((nodeA.col || 0) - (nodeB.col || 0));
        const dy = Math.abs((nodeA.row || 0) - (nodeB.row || 0));
        return dx + dy;
    }
    
    euclideanDistance(nodeA, nodeB) {
        if (!nodeA || !nodeB) return 0;
        const dx = (nodeA.col || 0) - (nodeB.col || 0);
        const dy = (nodeA.row || 0) - (nodeB.row || 0);
        return Math.sqrt(dx * dx + dy * dy);
    }
    
    reconstructPath(cameFrom, currentId) {
        const path = [currentId];
        while (cameFrom.has(currentId)) {
            currentId = cameFrom.get(currentId);
            path.unshift(currentId);
        }
        return path;
    }
    
    // Visualization control
    setAlgorithm(algorithm) {
        const validAlgorithms = ['bfs', 'dfs', 'a-star', 'dijkstra'];
        if (validAlgorithms.includes(algorithm)) {
            this.currentAlgorithm = algorithm;
            
            // Update UI
            document.querySelectorAll('.algorithm-card').forEach(card => {
                card.classList.remove('active');
                if (card.dataset.algorithm === algorithm) {
                    card.classList.add('active');
                }
            });
            
            // Update algorithm info
            this.updateAlgorithmInfo();
            
            return true;
        }
        return false;
    }
    
    updateAlgorithmInfo() {
        const info = {
            'bfs': {
                name: 'Breadth-First Search',
                time: 'O(V+E)',
                space: 'O(V)',
                optimal: 'Yes (unweighted)',
                complete: 'Yes'
            },
            'dfs': {
                name: 'Depth-First Search',
                time: 'O(V+E)',
                space: 'O(V)',
                optimal: 'No',
                complete: 'Yes'
            },
            'a-star': {
                name: 'A* Search',
                time: 'O(b^d)',
                space: 'O(b^d)',
                optimal: 'Yes',
                complete: 'Yes'
            },
            'dijkstra': {
                name: 'Dijkstra\'s Algorithm',
                time: 'O(V²)',
                space: 'O(V)',
                optimal: 'Yes',
                complete: 'Yes'
            }
        };
        
        const currentInfo = info[this.currentAlgorithm];
        if (currentInfo && document.getElementById('current-algorithm')) {
            document.getElementById('current-algorithm').textContent = currentInfo.name;
        }
    }
    
    setSpeed(speed) {
        this.visualizationSpeed = Math.max(1, Math.min(10, speed));
        const speeds = ['Very Slow', 'Slow', 'Medium Slow', 'Medium', 'Medium Fast', 'Fast', 'Very Fast'];
        const speedText = speeds[Math.floor((speed - 1) * (speeds.length - 1) / 9)] || 'Medium';
        
        if (document.getElementById('speed-value')) {
            document.getElementById('speed-value').textContent = speedText;
        }
    }
    
    generateRandomGraph(size = 8) {
        this.graph = new Graph();
        const rows = Math.ceil(Math.sqrt(size));
        const cols = Math.ceil(size / rows);
        
        const grid = this.graph.generateGrid(rows, cols);
        
        // Add some random walls/obstacles
        const wallCount = Math.floor(size * 0.2);
        for (let i = 0; i < wallCount; i++) {
            const randomRow = Math.floor(Math.random() * rows);
            const randomCol = Math.floor(Math.random() * cols);
            const node = grid[randomRow][randomCol];
            if (node && node.id !== '0' && node.id !== (size - 1).toString()) {
                node.type = 'wall';
            }
        }
        
        // Set start and end
        const startNode = grid[0][0];
        const endNode = grid[rows - 1][cols - 1];
        
        startNode.type = 'start';
        endNode.type = 'end';
        
        return {
            grid,
            startId: startNode.id,
            endId: endNode.id,
            rows,
            cols
        };
    }
    
    async visualize(graphData) {
        if (this.isRunning) {
            this.stop();
            await new Promise(resolve => setTimeout(resolve, 100));
        }
        
        this.isRunning = true;
        this.animationSteps = [];
        
        // Generate steps based on current algorithm
        let steps;
        switch (this.currentAlgorithm) {
            case 'bfs':
                steps = this.bfs(graphData.startId, graphData.endId);
                break;
            case 'dfs':
                steps = this.dfs(graphData.startId, graphData.endId);
                break;
            case 'a-star':
                steps = this.aStar(graphData.startId, graphData.endId);
                break;
            case 'dijkstra':
                steps = this.dijkstra(graphData.startId, graphData.endId);
                break;
            default:
                steps = this.bfs(graphData.startId, graphData.endId);
        }
        
        this.animationSteps = steps;
        this.currentStep = 0;
        
        // Calculate delay based on speed
        const baseDelay = 1000;
        const speedFactor = (11 - this.visualizationSpeed) / 10; // Invert so higher speed = faster
        const stepDelay = baseDelay * speedFactor;
        
        // Execute steps with delay
        for (let i = 0; i < steps.length && this.isRunning; i++) {
            await this.executeStep(steps[i], graphData);
            await new Promise(resolve => setTimeout(resolve, stepDelay));
        }
        
        this.isRunning = false;
        
        if (this.callbacks.onComplete) {
            this.callbacks.onComplete();
        }
    }
    
    executeStep(step, graphData) {
        this.currentStep++;
        
        // Update UI
        if (document.getElementById('nodes-visited')) {
            document.getElementById('nodes-visited').textContent = this.currentStep;
        }
        
        // Add to steps container
        if (document.getElementById('steps-container')) {
            const stepsContainer = document.getElementById('steps-container');
            const stepElement = document.createElement('div');
            stepElement.className = 'step';
            
            let stepText = '';
            switch (step.type) {
                case 'visit':
                    stepText = `Visiting node ${step.nodeId}`;
                    break;
                case 'discover':
                    stepText = `Discovered node ${step.nodeId} from ${step.from}`;
                    break;
                case 'found':
                    stepText = `Path found! Length: ${step.path.length}`;
                    if (document.getElementById('path-length')) {
                        document.getElementById('path-length').textContent = step.path.length;
                    }
                    break;
                case 'not_found':
                    stepText = 'No path found';
                    break;
            }
            
            stepElement.textContent = stepText;
            stepsContainer.appendChild(stepElement);
            stepsContainer.scrollTop = stepsContainer.scrollHeight;
        }
        
        // Visualize on graph
        if (this.callbacks.onNodeVisit) {
            this.callbacks.onNodeVisit(step);
        }
        
        return Promise.resolve();
    }
    
    stop() {
        this.isRunning = false;
    }
    
    reset() {
        this.stop();
        this.animationSteps = [];
        this.currentStep = 0;
        
        // Reset UI
        if (document.getElementById('nodes-visited')) {
            document.getElementById('nodes-visited').textContent = '0';
        }
        
        if (document.getElementById('path-length')) {
            document.getElementById('path-length').textContent = '0';
        }
        
        if (document.getElementById('steps-container')) {
            document.getElementById('steps-container').innerHTML = 
                '<div class="step">Ready to visualize...</div>';
        }
    }
    
    // Event handlers
    on(event, callback) {
        if (this.callbacks.hasOwnProperty(event)) {
            this.callbacks[event] = callback;
        }
    }
}

// Initialize global instance
window.algorithmVisualizer = new AlgorithmVisualizer();
console.log('Algorithm Visualizer loaded');