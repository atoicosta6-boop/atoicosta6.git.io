// ===========================================
// SOLVESPHERE - UTILITY FUNCTIONS
// Helper functions used across the application
// ===========================================

// DOM Utility Functions
class DOMUtils {
    // Get element by selector
    static $(selector) {
        return document.querySelector(selector);
    }
    
    // Get all elements by selector
    static $$(selector) {
        return document.querySelectorAll(selector);
    }
    
    // Create element with attributes
    static createElement(tag, attributes = {}, text = '') {
        const element = document.createElement(tag);
        
        // Set attributes
        Object.keys(attributes).forEach(key => {
            element.setAttribute(key, attributes[key]);
        });
        
        // Set text content
        if (text) {
            element.textContent = text;
        }
        
        return element;
    }
    
    // Add multiple classes
    static addClasses(element, ...classes) {
        element.classList.add(...classes);
    }
    
    // Remove multiple classes
    static removeClasses(element, ...classes) {
        element.classList.remove(...classes);
    }
    
    // Toggle multiple classes
    static toggleClasses(element, ...classes) {
        classes.forEach(cls => {
            element.classList.toggle(cls);
        });
    }
    
    // Check if element has class
    static hasClass(element, className) {
        return element.classList.contains(className);
    }
}

// String Utility Functions
class StringUtils {
    // Capitalize first letter
    static capitalize(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
    }
    
    // Format tool name
    static formatToolName(tool) {
        const names = {
            analyzer: 'Analyzer',
            database: 'Database',
            gps: 'GPS'
        };
        return names[tool] || this.capitalize(tool);
    }
    
    // Format status
    static formatStatus(status) {
        return status.charAt(0).toUpperCase() + status.slice(1);
    }
    
    // Generate random ID
    static generateId(prefix = 'id') {
        return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    }
    
    // Truncate text with ellipsis
    static truncate(text, maxLength = 100) {
        if (text.length <= maxLength) return text;
        return text.substr(0, maxLength) + '...';
    }
}

// Number Utility Functions
class NumberUtils {
    // Format number with commas
    static formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
    
    // Generate random number in range
    static random(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }
    
    // Clamp number between min and max
    static clamp(num, min, max) {
        return Math.min(Math.max(num, min), max);
    }
    
    // Linear interpolation
    static lerp(start, end, amount) {
        return start + (end - start) * amount;
    }
}

// Date Utility Functions
class DateUtils {
    // Format date
    static formatDate(date, format = 'dd/mm/yyyy') {
        const d = new Date(date);
        const day = d.getDate().toString().padStart(2, '0');
        const month = (d.getMonth() + 1).toString().padStart(2, '0');
        const year = d.getFullYear();
        
        switch (format) {
            case 'dd/mm/yyyy':
                return `${day}/${month}/${year}`;
            case 'mm/dd/yyyy':
                return `${month}/${day}/${year}`;
            case 'yyyy-mm-dd':
                return `${year}-${month}-${day}`;
            default:
                return d.toLocaleDateString();
        }
    }
    
    // Get time ago
    static getTimeAgo(date) {
        const now = new Date();
        const diff = now - new Date(date);
        
        const seconds = Math.floor(diff / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);
        
        if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        return `${seconds} second${seconds > 1 ? 's' : ''} ago`;
    }
}

// Storage Utility Functions
class StorageUtils {
    // Set item with expiry
    static setItem(key, value, expiryHours = 24) {
        const item = {
            value: value,
            expiry: Date.now() + (expiryHours * 60 * 60 * 1000)
        };
        localStorage.setItem(key, JSON.stringify(item));
    }
    
    // Get item with expiry check
    static getItem(key) {
        const itemStr = localStorage.getItem(key);
        
        if (!itemStr) return null;
        
        const item = JSON.parse(itemStr);
        
        // Check if expired
        if (Date.now() > item.expiry) {
            localStorage.removeItem(key);
            return null;
        }
        
        return item.value;
    }
    
    // Remove item
    static removeItem(key) {
        localStorage.removeItem(key);
    }
    
    // Clear all storage
    static clear() {
        localStorage.clear();
    }
}

// Event Utility Functions
class EventUtils {
    // Debounce function
    static debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }
    
    // Throttle function
    static throttle(func, limit) {
        let inThrottle;
        return function() {
            const args = arguments;
            const context = this;
            if (!inThrottle) {
                func.apply(context, args);
                inThrottle = true;
                setTimeout(() => inThrottle = false, limit);
            }
        };
    }
    
    // Add event listener with debounce
    static addDebouncedListener(element, event, func, wait) {
        element.addEventListener(event, this.debounce(func, wait));
    }
    
    // Add event listener with throttle
    static addThrottledListener(element, event, func, limit) {
        element.addEventListener(event, this.throttle(func, limit));
    }
}

// Validation Utility Functions
class ValidationUtils {
    // Validate email
    static isValidEmail(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    
    // Validate phone number (basic)
    static isValidPhone(phone) {
        const regex = /^[\d\s\-\+\(\)]{10,}$/;
        return regex.test(phone);
    }
    
    // Validate URL
    static isValidUrl(url) {
        try {
            new URL(url);
            return true;
        } catch (e) {
            return false;
        }
    }
    
    // Check if string is empty
    static isEmpty(str) {
        return !str || str.trim().length === 0;
    }
}

// Performance Utility Functions
class PerformanceUtils {
    // Measure function execution time
    static measureTime(func, ...args) {
        const start = performance.now();
        const result = func(...args);
        const end = performance.now();
        
        console.log(`Function executed in ${(end - start).toFixed(2)}ms`);
        return result;
    }
    
    // Check if page is loaded
    static isPageLoaded() {
        return document.readyState === 'complete';
    }
    
    // Get memory usage (if supported)
    static getMemoryUsage() {
        if (performance.memory) {
            return {
                used: performance.memory.usedJSHeapSize,
                total: performance.memory.totalJSHeapSize,
                limit: performance.memory.jsHeapSizeLimit
            };
        }
        return null;
    }
}

// Color Utility Functions
class ColorUtils {
    // Convert hex to rgba
    static hexToRgba(hex, alpha = 1) {
        const r = parseInt(hex.slice(1, 3), 16);
        const g = parseInt(hex.slice(3, 5), 16);
        const b = parseInt(hex.slice(5, 7), 16);
        
        return `rgba(${r}, ${g}, ${b}, ${alpha})`;
    }
    
    // Generate random color
    static randomColor() {
        return `#${Math.floor(Math.random() * 16777215).toString(16)}`;
    }
    
    // Generate gradient colors
    static generateGradient(color1, color2, steps = 5) {
        const colors = [];
        for (let i = 0; i < steps; i++) {
            const ratio = i / (steps - 1);
            colors.push(this.interpolateColor(color1, color2, ratio));
        }
        return colors;
    }
    
    // Interpolate between two colors
    static interpolateColor(color1, color2, ratio) {
        const r1 = parseInt(color1.slice(1, 3), 16);
        const g1 = parseInt(color1.slice(3, 5), 16);
        const b1 = parseInt(color1.slice(5, 7), 16);
        
        const r2 = parseInt(color2.slice(1, 3), 16);
        const g2 = parseInt(color2.slice(3, 5), 16);
        const b2 = parseInt(color2.slice(5, 7), 16);
        
        const r = Math.round(r1 + (r2 - r1) * ratio);
        const g = Math.round(g1 + (g2 - g1) * ratio);
        const b = Math.round(b1 + (b2 - b1) * ratio);
        
        return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
    }
}

// Export all utilities
window.SolveSphereUtils = {
    DOM: DOMUtils,
    String: StringUtils,
    Number: NumberUtils,
    Date: DateUtils,
    Storage: StorageUtils,
    Event: EventUtils,
    Validation: ValidationUtils,
    Performance: PerformanceUtils,
    Color: ColorUtils
};

console.log('SolveSphere Utilities loaded successfully');