// navigation.js
// Handle multi-page navigation with smooth transitions

class NavigationManager {
    constructor() {
        this.currentPage = window.location.pathname.split('/').pop() || 'index.html';
        this.isTransitioning = false;
        this.init();
    }

    init() {
        // Add page transition container to body
        this.createTransitionContainer();
        
        // Setup navigation links
        this.setupNavLinks();
        
        // Handle back/forward browser buttons
        window.addEventListener('popstate', this.handlePopState.bind(this));
        
        // Handle initial page load
        this.updateActiveNav();
        
        // Setup mobile menu toggle
        this.setupMobileMenu();
    }

    createTransitionContainer() {
        const transitionContainer = document.createElement('div');
        transitionContainer.className = 'page-transition';
        transitionContainer.innerHTML = `
            <div class="page-loading">
                <div class="loading-spinner"></div>
            </div>
        `;
        document.body.appendChild(transitionContainer);
        this.transitionContainer = transitionContainer;
    }

    setupNavLinks() {
        // Add click handlers to all navigation links
        document.querySelectorAll('[data-page]').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const page = link.getAttribute('data-page');
                if (page !== this.currentPage && !this.isTransitioning) {
                    this.navigateTo(page);
                }
            });
        });
    }

    setupMobileMenu() {
        const navToggle = document.getElementById('nav-toggle');
        const navMenu = document.getElementById('nav-menu');
        
        if (navToggle && navMenu) {
            navToggle.addEventListener('click', () => {
                navMenu.classList.toggle('active');
                navToggle.innerHTML = navMenu.classList.contains('active') 
                    ? '<i class="fas fa-times"></i>' 
                    : '<i class="fas fa-bars"></i>';
            });
        }
    }

    navigateTo(page) {
        if (this.isTransitioning) return;
        
        this.isTransitioning = true;
        
        // Start transition animation
        this.transitionContainer.classList.add('active');
        
        // Update navigation state
        this.updateNavState(page);
        
        // Load page content
        setTimeout(() => {
            this.loadPageContent(page)
                .then(() => {
                    // Update current page
                    this.currentPage = page;
                    
                    // Update active navigation
                    this.updateActiveNav();
                    
                    // Close mobile menu if open
                    const navMenu = document.getElementById('nav-menu');
                    const navToggle = document.getElementById('nav-toggle');
                    if (navMenu && navMenu.classList.contains('active')) {
                        navMenu.classList.remove('active');
                        if (navToggle) {
                            navToggle.innerHTML = '<i class="fas fa-bars"></i>';
                        }
                    }
                    
                    // Scroll to top
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    
                    // Initialize page-specific content
                    this.initializePageContent();
                    
                    // End transition
                    setTimeout(() => {
                        this.transitionContainer.classList.remove('active');
                        this.transitionContainer.classList.add('out');
                        
                        setTimeout(() => {
                            this.transitionContainer.classList.remove('out');
                            this.isTransitioning = false;
                        }, 600);
                    }, 100);
                })
                .catch(error => {
                    console.error('Error loading page:', error);
                    this.isTransitioning = false;
                    this.transitionContainer.classList.remove('active');
                    
                    // Fallback to traditional navigation
                    window.location.href = page;
                });
        }, 300);
    }

    async loadPageContent(page) {
        try {
            const response = await fetch(page);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            
            const html = await response.text();
            
            // Extract content from the loaded page
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');
            
            // Update main content
            const mainContent = doc.querySelector('.main-content');
            if (mainContent) {
                document.querySelector('.main-content').innerHTML = mainContent.innerHTML;
            }
            
            // Update page title
            document.title = doc.title || this.getPageTitle(page);
            
            // Update theme if needed
            const theme = doc.documentElement.getAttribute('data-theme');
            if (theme) {
                document.documentElement.setAttribute('data-theme', theme);
            }
            
            // Update theme switch state
            this.updateThemeSwitch(theme);
            
            // Load new scripts
            const newScripts = Array.from(doc.querySelectorAll('script[src$=".js"]'));
            await this.loadNewScripts(newScripts);
            
            // Reinitialize components
            this.reinitializeComponents();
            
        } catch (error) {
            console.error('Error loading page content:', error);
            throw error;
        }
    }

    async loadNewScripts(scripts) {
        const promises = scripts.map(script => {
            return new Promise((resolve, reject) => {
                // Check if script already exists
                const existingScript = document.querySelector(`script[src="${script.src}"]`);
                if (existingScript) {
                    resolve();
                    return;
                }
                
                const newScript = document.createElement('script');
                newScript.src = script.src;
                newScript.onload = resolve;
                newScript.onerror = reject;
                document.body.appendChild(newScript);
            });
        });
        
        return Promise.all(promises);
    }

    reinitializeComponents() {
        // Reinitialize any components that need it
        if (window.solveSphereApp) {
            window.solveSphereApp.setupEventListeners();
            window.solveSphereApp.setupAnimations();
            window.solveSphereApp.setupCursorGlow();
            window.solveSphereApp.setupParticles();
        }
        
        // Reinitialize theme toggle
        this.initializeThemeToggle();
        
        // Reinitialize navigation
        this.setupNavLinks();
        this.setupMobileMenu();
    }

    initializePageContent() {
        // Initialize page-specific content based on current page
        switch(this.currentPage) {
            case 'solutions.html':
                this.initializeSolutionsPage();
                break;
            case 'team.html':
                this.initializeTeamPage();
                break;
            case 'about.html':
                this.initializeAboutPage();
                break;
        }
        
        // Add fade-in animations to new content
        this.animatePageContent();
    }

    animatePageContent() {
        // Add fade-in animations to new elements
        const elements = document.querySelectorAll('.solution-item, .team-member-card, .mission-card, .problem-card');
        elements.forEach((element, index) => {
            element.classList.add('fade-in-up');
            element.style.animationDelay = `${index * 0.1}s`;
        });
    }

    initializeSolutionsPage() {
        // Initialize solutions page functionality
        const tabs = document.querySelectorAll('.category-tab');
        const items = document.querySelectorAll('.solution-item');
        
        if (tabs.length > 0 && items.length > 0) {
            tabs.forEach(tab => {
                tab.addEventListener('click', () => {
                    // Update active tab
                    tabs.forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    
                    // Filter items
                    const category = tab.dataset.category;
                    
                    items.forEach(item => {
                        if (category === 'all' || item.dataset.category === category) {
                            item.style.display = 'block';
                            setTimeout(() => {
                                item.classList.add('fade-in-up');
                            }, 10);
                        } else {
                            item.style.display = 'none';
                            item.classList.remove('fade-in-up');
                        }
                    });
                });
            });
        }
    }

    initializeTeamPage() {
        // Initialize team page functionality
        // Could add filtering or search functionality here
    }

    initializeAboutPage() {
        // Initialize about page functionality
    }

    initializeThemeToggle() {
        const themeSwitch = document.getElementById('theme-switch');
        if (themeSwitch) {
            const currentTheme = document.documentElement.getAttribute('data-theme');
            themeSwitch.checked = currentTheme === 'dark';
            
            themeSwitch.addEventListener('change', (e) => {
                if (e.target.checked) {
                    document.documentElement.setAttribute('data-theme', 'dark');
                    localStorage.setItem('theme', 'dark');
                } else {
                    document.documentElement.setAttribute('data-theme', 'light');
                    localStorage.setItem('theme', 'light');
                }
            });
        }
    }

    updateThemeSwitch(theme) {
        const themeSwitch = document.getElementById('theme-switch');
        if (themeSwitch) {
            themeSwitch.checked = theme === 'dark';
        }
    }

    updateNavState(page) {
        // Update browser history
        const state = { page };
        const title = this.getPageTitle(page);
        const url = page;
        
        history.pushState(state, title, url);
    }

    handlePopState(event) {
        if (event.state && event.state.page && !this.isTransitioning) {
            this.navigateTo(event.state.page);
        }
    }

    updateActiveNav() {
        // Update active state in navigation
        document.querySelectorAll('[data-page]').forEach(link => {
            const page = link.getAttribute('data-page');
            if (page === this.currentPage) {
                link.classList.add('active');
            } else {
                link.classList.remove('active');
            }
        });
    }

    getPageTitle(page) {
        const titles = {
            'index.html': 'SolveSphere - Problem Solving Platform',
            'solutions.html': 'SolveSphere - AI Solutions',
            'about.html': 'SolveSphere - Tentang Kami',
            'team.html': 'SolveSphere - Tim Ahli'
        };
        return titles[page] || 'SolveSphere';
    }

    // Public method for external navigation
    goToPage(page) {
        if (!this.isTransitioning) {
            this.navigateTo(page);
        }
    }
}

// Initialize navigation manager when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.navigationManager = new NavigationManager();
    
    // Add global navigation helper
    window.navigateTo = (page) => {
        if (window.navigationManager) {
            window.navigationManager.goToPage(page);
        } else {
            window.location.href = page;
        }
    };
});

// Handle initial page animations
window.addEventListener('load', () => {
    // Add initial animations to page elements
    const animatedElements = document.querySelectorAll('.solution-item, .team-member-card, .mission-card');
    animatedElements.forEach((element, index) => {
        element.classList.add('fade-in-up');
        element.style.animationDelay = `${index * 0.1}s`;
    });
});