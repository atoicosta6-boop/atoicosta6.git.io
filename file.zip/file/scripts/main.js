// Main Application Script
class SolveSphereApp {
    constructor() {
        this.init();
    }

    init() {
        // Initialize components
        this.setupEventListeners();
        this.setupToolStatus();
        this.setupBackgroundEffects();
        
        console.log('SolveSphere App initialized');
    }

    setupEventListeners() {
        // Setup stop loading button
        this.setupStopLoadingButton();
        
        // Setup tool status interactions
        this.setupToolStatusInteractions();
        
        // Setup responsive behaviors
        this.setupResponsiveBehaviors();
    }

    setupStopLoadingButton() {
        const stopLoadingBtn = document.getElementById('stop-loading-btn');
        
        if (stopLoadingBtn) {
            stopLoadingBtn.addEventListener('click', () => {
                this.stopAllProcesses();
            });
        }
    }

    stopAllProcesses() {
        // Stop animations
        if (window.animationSystem) {
            animationSystem.stopAllAnimations();
        }
        
        // Show notification
        this.showNotification('All processes stopped successfully', 'success');
        
        // Update button state
        const btn = document.getElementById('stop-loading-btn');
        if (btn) {
            const icon = btn.querySelector('i');
            const text = btn.querySelector('span');
            
            // Change to stopped state
            icon.className = 'fas fa-check-circle';
            text.textContent = 'Stopped';
            btn.disabled = true;
            btn.style.opacity = '0.7';
            
            // Reset after 3 seconds
            setTimeout(() => {
                icon.className = 'fas fa-stop-circle';
                text.textContent = 'Stop Loading';
                btn.disabled = false;
                btn.style.opacity = '1';
            }, 3000);
        }
        
        // Update tool status
        this.updateToolStatus('stopped');
    }

    setupToolStatus() {
        // Initialize tool status from localStorage or default
        const savedStatus = localStorage.getItem('solveSphereToolStatus');
        if (savedStatus) {
            const status = JSON.parse(savedStatus);
            this.applyToolStatus(status);
        } else {
            // Default status
            const defaultStatus = {
                analyzer: 'active',
                database: 'connected',
                gps: 'tracking'
            };
            localStorage.setItem('solveSphereToolStatus', JSON.stringify(defaultStatus));
            this.applyToolStatus(defaultStatus);
        }
    }

    applyToolStatus(status) {
        Object.keys(status).forEach(tool => {
            const element = document.querySelector(`[data-tool="${tool}"]`);
            if (element) {
                if (status[tool] === 'stopped') {
                    element.classList.remove('active');
                    element.innerHTML = `
                        <i class="fas fa-pause-circle"></i>
                        <span>${this.formatToolName(tool)} Stopped</span>
                    `;
                } else {
                    element.classList.add('active');
                    element.innerHTML = `
                        <i class="${this.getToolIcon(tool)}"></i>
                        <span>${this.formatToolName(tool)} ${this.formatStatus(status[tool])}</span>
                    `;
                }
            }
        });
    }

    formatToolName(tool) {
        const names = {
            analyzer: 'Analyzer',
            database: 'Database',
            gps: 'GPS'
        };
        return names[tool] || tool;
    }

    formatStatus(status) {
        return status.charAt(0).toUpperCase() + status.slice(1);
    }

    getToolIcon(tool) {
        const icons = {
            analyzer: 'fas fa-exclamation-triangle',
            database: 'fas fa-database',
            gps: 'fas fa-map-marker-alt'
        };
        return icons[tool] || 'fas fa-cog';
    }

    updateToolStatus(newStatus) {
        const currentStatus = JSON.parse(localStorage.getItem('solveSphereToolStatus') || '{}');
        const updatedStatus = { ...currentStatus, ...newStatus };
        localStorage.setItem('solveSphereToolStatus', JSON.stringify(updatedStatus));
        this.applyToolStatus(updatedStatus);
    }

    setupToolStatusInteractions() {
        // Make tool status clickable to toggle
        document.querySelectorAll('.tool-status').forEach(tool => {
            tool.addEventListener('click', () => {
                const toolName = tool.dataset.tool;
                const currentStatus = JSON.parse(localStorage.getItem('solveSphereToolStatus') || '{}');
                
                if (currentStatus[toolName] === 'stopped') {
                    // Restart tool
                    const newStatus = { ...currentStatus, [toolName]: this.getDefaultToolStatus(toolName) };
                    this.updateToolStatus(newStatus);
                    this.showNotification(`${this.formatToolName(toolName)} restarted`, 'success');
                } else {
                    // Stop tool
                    const newStatus = { ...currentStatus, [toolName]: 'stopped' };
                    this.updateToolStatus(newStatus);
                    this.showNotification(`${this.formatToolName(toolName)} stopped`, 'warning');
                }
            });
        });
    }

    getDefaultToolStatus(tool) {
        const defaults = {
            analyzer: 'active',
            database: 'connected',
            gps: 'tracking'
        };
        return defaults[tool] || 'active';
    }

    setupBackgroundEffects() {
        // Setup cursor glow effect
        this.setupCursorGlow();
        
        // Setup glass morphism effects
        this.setupGlassEffects();
    }

    setupCursorGlow() {
        document.addEventListener('mousemove', (e) => {
            const glow = document.querySelector('.cursor-glow');
            if (glow) {
                glow.style.left = `${e.clientX}px`;
                glow.style.top = `${e.clientY}px`;
            }
        });
    }

    setupGlassEffects() {
        // Animate glass circles
        const circles = document.querySelectorAll('.glass-circle');
        circles.forEach((circle, index) => {
            circle.style.animationDelay = `${index * 2}s`;
        });
    }

    setupResponsiveBehaviors() {
        // Handle window resize
        window.addEventListener('resize', () => {
            this.handleResize();
        });
        
        // Initial resize handling
        this.handleResize();
    }

    handleResize() {
        const isMobile = window.innerWidth <= 768;
        
        // Update body class for responsive styling
        if (isMobile) {
            document.body.classList.add('mobile-view');
        } else {
            document.body.classList.remove('mobile-view');
        }
        
        // Adjust floating cube size on mobile
        const cube = document.querySelector('.floating-cube');
        if (cube) {
            if (isMobile) {
                cube.style.width = '200px';
                cube.style.height = '200px';
            } else {
                cube.style.width = '300px';
                cube.style.height = '300px';
            }
        }
    }

    showNotification(message, type = 'info') {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = `notification notification-${type}`;
        notification.innerHTML = `
            <i class="fas fa-${this.getNotificationIcon(type)}"></i>
            <span>${message}</span>
            <button class="notification-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        // Add styles if not already added
        if (!document.querySelector('#notification-styles')) {
            const style = document.createElement('style');
            style.id = 'notification-styles';
            style.textContent = `
                .notification {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    background: white;
                    color: #333;
                    padding: 15px 20px;
                    border-radius: 10px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                    display: flex;
                    align-items: center;
                    gap: 10px;
                    z-index: 1000;
                    animation: slideInRight 0.3s ease-out;
                    max-width: 400px;
                }
                
                @keyframes slideInRight {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
                
                .notification-success {
                    border-left: 4px solid #10b981;
                }
                
                .notification-warning {
                    border-left: 4px solid #f59e0b;
                }
                
                .notification-info {
                    border-left: 4px solid #6366f1;
                }
                
                .notification-error {
                    border-left: 4px solid #ef4444;
                }
                
                .notification-close {
                    background: none;
                    border: none;
                    color: #666;
                    cursor: pointer;
                    margin-left: auto;
                }
            `;
            document.head.appendChild(style);
        }
        
        // Add to document
        document.body.appendChild(notification);
        
        // Auto remove after 5 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
        
        // Close button functionality
        const closeBtn = notification.querySelector('.notification-close');
        closeBtn.addEventListener('click', () => {
            notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
            setTimeout(() => notification.remove(), 300);
        });
    }

    getNotificationIcon(type) {
        const icons = {
            success: 'check-circle',
            warning: 'exclamation-triangle',
            info: 'info-circle',
            error: 'times-circle'
        };
        return icons[type] || 'info-circle';
    }

    // Utility method for creating staggered animations
    createStaggerAnimation(selector, animation = 'fade-in-up', delay = 0.1) {
        const elements = document.querySelectorAll(selector);
        elements.forEach((element, index) => {
            element.style.animationDelay = `${index * delay}s`;
            element.classList.add(animation);
        });
    }
}

// Initialize the app when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.solveSphereApp = new SolveSphereApp();
    
    // Add slideOutRight animation
    const animationStyle = document.createElement('style');
    animationStyle.textContent = `
        @keyframes slideOutRight {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(animationStyle);
    
    console.log('SolveSphere platform ready');
});