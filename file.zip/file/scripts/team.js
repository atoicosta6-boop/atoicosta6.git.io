// ===========================================
// SOLVESPHERE - TEAM PAGE FUNCTIONALITY
// Interactive features for team.html
// ===========================================

class TeamManager {
    constructor() {
        this.members = [];
        this.currentView = 'grid'; // 'grid' or 'list'
        this.currentProfile = 'maria';
        this.initializeMembers();
    }
    
    initializeMembers() {
        this.members = [
            {
                id: 'maria',
                name: 'Maria Silva',
                role: 'CEO & Founder',
                image: 'assets/profiles/ceo.jpg',
                location: 'Dili, Timor-Leste',
                education: 'PhD in AI',
                bio: 'Visionary leader with 10+ years in AI and machine learning. Founded SolveSphere to democratize access to advanced problem-solving tools.',
                skills: ['Strategic Leadership', 'AI Research', 'Business Development'],
                email: 'maria@solvesphere.com',
                social: {
                    linkedin: '#',
                    twitter: '#',
                    github: '#'
                },
                details: {
                    education: [
                        'PhD in Artificial Intelligence - Stanford University (2015)',
                        'MSc in Computer Science - MIT (2012)',
                        'BSc in Mathematics - University of Lisbon (2010)'
                    ],
                    experience: [
                        'Senior AI Researcher - Google Research (2016-2020)',
                        'Lead Data Scientist - Amazon Web Services (2015-2016)',
                        'AI Consultant - McKinsey & Company (2013-2015)'
                    ],
                    achievements: [
                        'Forbes 30 Under 30 - Technology (2019)',
                        'Best Paper Award - NeurIPS Conference (2018)',
                        'AI Innovator of the Year - TechCrunch (2021)'
                    ],
                    stats: {
                        experience: 12,
                        projects: 45,
                        papers: 8
                    }
                }
            },
            {
                id: 'john',
                name: 'John Santos',
                role: 'Chief Technology Officer',
                image: 'assets/profiles/cto.jpg',
                location: 'Baucau, Timor-Leste',
                education: 'MSc Computer Science',
                bio: 'Expert in scalable system architecture and algorithm optimization. Leads our technical team in building robust AI solutions.',
                skills: ['System Architecture', 'DevOps', 'Cloud Computing'],
                email: 'john@solvesphere.com',
                social: {
                    linkedin: '#',
                    twitter: '#',
                    github: '#'
                }
            },
            {
                id: 'ana',
                name: 'Ana Pereira',
                role: 'Lead AI Developer',
                image: 'assets/profiles/lead-dev.jpg',
                location: 'Maliana, Timor-Leste',
                education: 'PhD Neural Networks',
                bio: 'Specialist in neural networks and computer vision. Published researcher with contributions to multiple AI conferences.',
                skills: ['Neural Networks', 'Computer Vision', 'TensorFlow'],
                email: 'ana@solvesphere.com',
                social: {
                    linkedin: '#',
                    researchgate: '#',
                    github: '#'
                }
            },
            {
                id: 'carlos',
                name: 'Carlos Mendes',
                role: 'Senior Data Scientist',
                image: 'assets/profiles/data-scientist.jpg',
                location: 'Suai, Timor-Leste',
                education: 'MSc Statistics',
                bio: 'Expert in statistical analysis and predictive modeling. Transforms complex data into actionable insights for decision making.',
                skills: ['Predictive Analytics', 'Big Data', 'Python/R'],
                email: 'carlos@solvesphere.com',
                social: {
                    linkedin: '#',
                    kaggle: '#',
                    github: '#'
                }
            },
            {
                id: 'sofia',
                name: 'Sofia Rodrigues',
                role: 'Frontend Developer',
                image: 'assets/profiles/frontend.jpg',
                location: 'Oecusse, Timor-Leste',
                education: 'BSc Design & CS',
                bio: 'Creates beautiful, responsive user interfaces with modern web technologies. Focuses on user experience and accessibility.',
                skills: ['React/Vue.js', 'UI/UX Design', 'Animation'],
                email: 'sofia@solvesphere.com',
                social: {
                    linkedin: '#',
                    dribbble: '#',
                    github: '#'
                }
            },
            {
                id: 'miguel',
                name: 'Miguel Oliveira',
                role: 'Backend Developer',
                image: 'assets/profiles/backend.jpg',
                location: 'Liquiçá, Timor-Leste',
                education: 'BSc Software Engineering',
                bio: 'Builds scalable APIs and microservices with focus on performance and security. Expert in database optimization and server architecture.',
                skills: ['Node.js/Python', 'API Design', 'Database'],
                email: 'miguel@solvesphere.com',
                social: {
                    linkedin: '#',
                    stackoverflow: '#',
                    github: '#'
                }
            }
        ];
    }
    
    init() {
        this.setupEventListeners();
        this.setupMemberHoverEffects();
        this.setupContactForm();
        this.initializeCounters();
        
        console.log('Team Manager initialized with', this.members.length, 'members');
    }
    
    setupEventListeners() {
        // View toggle
        const viewToggle = document.getElementById('view-toggle');
        if (viewToggle) {
            viewToggle.addEventListener('click', () => {
                this.toggleView();
            });
        }
        
        // Profile tabs
        const profileTabs = document.querySelectorAll('[data-profile]');
        profileTabs.forEach(tab => {
            tab.addEventListener('click', (e) => {
                const profileId = e.currentTarget.dataset.profile;
                this.showProfile(profileId);
            });
        });
        
        // Member card clicks
        const memberCards = document.querySelectorAll('.member-card');
        memberCards.forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.closest('.social-link') && !e.target.closest('.contact-btn')) {
                    const memberId = card.dataset.member;
                    if (memberId) {
                        this.showProfileDetails(memberId);
                    }
                }
            });
        });
    }
    
    setupMemberHoverEffects() {
        const memberCards = document.querySelectorAll('.member-card');
        
        memberCards.forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.classList.add('hover-active');
                this.animateCard(card);
            });
            
            card.addEventListener('mouseleave', () => {
                card.classList.remove('hover-active');
            });
        });
    }
    
    animateCard(card) {
        // Add subtle animation effects
        const image = card.querySelector('.member-photo img');
        if (image) {
            image.style.transition = 'transform 0.5s ease';
        }
        
        const skills = card.querySelectorAll('.skill-tag');
        skills.forEach((skill, index) => {
            skill.style.animationDelay = `${index * 0.1}s`;
            skill.classList.add('animate-in');
        });
    }
    
    toggleView() {
        const membersGrid = document.getElementById('members-grid');
        const viewToggle = document.getElementById('view-toggle');
        
        if (!membersGrid || !viewToggle) return;
        
        this.currentView = this.currentView === 'grid' ? 'list' : 'grid';
        
        // Update grid class
        membersGrid.classList.remove('grid-view', 'list-view');
        membersGrid.classList.add(`${this.currentView}-view`);
        
        // Update button text and icon
        const icon = viewToggle.querySelector('i');
        const text = viewToggle.querySelector('span');
        
        if (this.currentView === 'grid') {
            icon.className = 'fas fa-th-large';
            text.textContent = 'Grid View';
        } else {
            icon.className = 'fas fa-list';
            text.textContent = 'List View';
        }
        
        // Animate transition
        membersGrid.style.opacity = '0.5';
        setTimeout(() => {
            membersGrid.style.opacity = '1';
            membersGrid.style.transition = 'opacity 0.3s ease';
        }, 10);
    }
    
    showProfile(profileId) {
        this.currentProfile = profileId;
        
        // Update active tab
        document.querySelectorAll('.tab-nav').forEach(tab => {
            tab.classList.remove('active');
            if (tab.dataset.tab === profileId) {
                tab.classList.add('active');
            }
        });
        
        // Update content
        document.querySelectorAll('.tab-pane').forEach(pane => {
            pane.classList.remove('active');
            if (pane.id === `${profileId}-tab`) {
                pane.classList.add('active');
                
                // Load profile data if not already loaded
                this.loadProfileData(profileId, pane);
            }
        });
        
        // Smooth scroll to profile section
        const profileSection = document.querySelector('.team-profiles');
        if (profileSection) {
            profileSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    
    loadProfileData(profileId, container) {
        const member = this.members.find(m => m.id === profileId);
        if (!member || !member.details) return;
        
        // Check if already loaded
        if (container.querySelector('.profile-loaded')) return;
        
        // Create detailed profile content
        const profileDetail = this.createProfileDetail(member);
        container.innerHTML = '';
        container.appendChild(profileDetail);
        container.classList.add('profile-loaded');
        
        // Add animation
        container.style.animation = 'fadeIn 0.5s ease-out';
    }
    
    createProfileDetail(member) {
        const detailDiv = document.createElement('div');
        detailDiv.className = 'profile-detail';
        
        detailDiv.innerHTML = `
            <div class="profile-header">
                <div class="profile-image">
                    <img src="${member.image}" alt="${member.name}" 
                         onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face'">
                </div>
                <div class="profile-info">
                    <h3>${member.name}</h3>
                    <p class="profile-role">${member.role}</p>
                    <div class="profile-stats">
                        <div class="stat">
                            <div class="stat-number">${member.details.stats.experience}</div>
                            <div class="stat-label">Years Experience</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number">${member.details.stats.projects}+</div>
                            <div class="stat-label">Projects Led</div>
                        </div>
                        <div class="stat">
                            <div class="stat-number">${member.details.stats.papers}</div>
                            <div class="stat-label">Research Papers</div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="profile-content">
                <div class="profile-section">
                    <h4><i class="fas fa-graduation-cap"></i> Education</h4>
                    <ul>
                        ${member.details.education.map(item => `<li><strong>${item}</strong></li>`).join('')}
                    </ul>
                </div>
                
                <div class="profile-section">
                    <h4><i class="fas fa-briefcase"></i> Experience</h4>
                    <ul>
                        ${member.details.experience.map(item => `<li><strong>${item}</strong></li>`).join('')}
                    </ul>
                </div>
                
                <div class="profile-section">
                    <h4><i class="fas fa-star"></i> Achievements</h4>
                    <ul>
                        ${member.details.achievements.map(item => `<li>${item}</li>`).join('')}
                    </ul>
                </div>
            </div>
        `;
        
        return detailDiv;
    }
    
    showProfileDetails(memberId) {
        // Show the detailed profile tab
        this.showProfile(memberId);
    }
    
    setupContactForm() {
        const contactForm = document.getElementById('team-contact-form');
        if (!contactForm) return;
        
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get form data
            const formData = new FormData(contactForm);
            const data = {
                name: formData.get('name') || document.getElementById('contact-name').value,
                email: formData.get('email') || document.getElementById('contact-email').value,
                subject: formData.get('subject') || document.getElementById('contact-subject').value,
                message: formData.get('message') || document.getElementById('contact-message').value
            };
            
            // Validate
            if (!data.name || !data.email || !data.subject || !data.message) {
                this.showNotification('Please fill in all fields', 'error');
                return;
            }
            
            if (!this.validateEmail(data.email)) {
                this.showNotification('Please enter a valid email address', 'error');
                return;
            }
            
            // Simulate form submission
            const submitBtn = contactForm.querySelector('button[type="submit"]');
            const originalText = submitBtn.innerHTML;
            
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Sending...</span>';
            
            // Simulate API call
            setTimeout(() => {
                this.showNotification('Message sent successfully! We will get back to you soon.', 'success');
                contactForm.reset();
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
            }, 1500);
        });
    }
    
    validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    showNotification(message, type = 'info') {
        // Use existing notification system or create one
        if (window.notificationSystem) {
            notificationSystem.show(message, type);
        } else {
            // Fallback notification
            const notification = document.createElement('div');
            notification.className = `team-notification ${type}`;
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 20px;
                background: ${type === 'success' ? '#10b981' : '#ef4444'};
                color: white;
                border-radius: 8px;
                z-index: 10000;
                animation: slideInRight 0.3s ease-out;
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOutRight 0.3s ease-out forwards';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }
    }
    
    initializeCounters() {
        // Initialize counter animations
        const counters = document.querySelectorAll('.count-up');
        counters.forEach(counter => {
            const target = parseInt(counter.dataset.counter) || 0;
            const duration = 2000;
            const increment = target / (duration / 16);
            let current = 0;
            
            const updateCounter = () => {
                current += increment;
                if (current >= target) {
                    current = target;
                    counter.textContent = target + (counter.dataset.counterSuffix || '');
                } else {
                    counter.textContent = Math.floor(current) + (counter.dataset.counterSuffix || '');
                    requestAnimationFrame(updateCounter);
                }
            };
            
            // Start when element is in viewport
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        updateCounter();
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.5 });
            
            observer.observe(counter);
        });
    }
    
    // Utility methods
    getMemberById(id) {
        return this.members.find(member => member.id === id);
    }
    
    getAllMembers() {
        return this.members;
    }
    
    filterMembersBySkill(skill) {
        return this.members.filter(member => 
            member.skills.some(s => s.toLowerCase().includes(skill.toLowerCase()))
        );
    }
}

// Initialize team manager
window.teamManager = new TeamManager();

// Additional team page animations
document.addEventListener('DOMContentLoaded', function() {
    // Add staggered animation to member cards
    const memberCards = document.querySelectorAll('.member-card');
    memberCards.forEach((card, index) => {
        card.style.animationDelay = `${index * 0.1}s`;
        card.classList.add('stagger-animate');
    });
    
    // Add hover effect to skill tags
    const skillTags = document.querySelectorAll('.skill-tag');
    skillTags.forEach(tag => {
        tag.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
        });
        
        tag.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
        });
    });
    
    // Add click effect to contact buttons
    const contactBtns = document.querySelectorAll('.contact-btn');
    contactBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            
            // Add ripple effect
            const ripple = document.createElement('span');
            const rect = this.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height);
            const x = e.clientX - rect.left - size / 2;
            const y = e.clientY - rect.top - size / 2;
            
            ripple.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                left: ${x}px;
                top: ${y}px;
                transform: scale(0);
                animation: ripple 0.6s linear;
            `;
            
            this.appendChild(ripple);
            
            setTimeout(() => {
                ripple.remove();
            }, 600);
        });
    });
    
    // Add CSS for animations
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        .stagger-animate {
            animation: fadeInUp 0.5s ease-out forwards;
            opacity: 0;
        }
        
        .skill-tag.animate-in {
            animation: bounceIn 0.3s ease-out forwards;
        }
        
        .member-card.hover-active {
            z-index: 10;
        }
        
        .team-notification {
            font-family: 'Poppins', sans-serif;
            font-weight: 500;
        }
    `;
    document.head.appendChild(style);
});