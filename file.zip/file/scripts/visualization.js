// ===========================================
// SOLVESPHERE - GRAPH VISUALIZATION
// Visual rendering of algorithms and graphs
// ===========================================

class GraphVisualizer {
    constructor(containerId) {
        this.container = document.getElementById(containerId);
        this.canvas = null;
        this.ctx = null;
        this.nodes = [];
        this.edges = [];
        this.nodeRadius = 25;
        this.gridSize = 8;
        this.colors = {
            start: '#10b981',
            end: '#ef4444',
            visited: '#3b82f6',
            path: '#f59e0b',
            wall: '#64748b',
            empty: '#e2e8f0',
            text: '#1e293b'
        };
        
        this.initializeCanvas();
    }
    
    initializeCanvas() {
        if (!this.container) return;
        
        // Create canvas
        this.canvas = document.createElement('canvas');
        this.canvas.width = this.container.clientWidth;
        this.canvas.height = 500;
        this.canvas.style.backgroundColor = '#f8fafc';
        this.canvas.style.borderRadius = '12px';
        this.canvas.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
        
        this.container.appendChild(this.canvas);
        this.ctx = this.canvas.getContext('2d');
        
        // Handle window resize
        window.addEventListener('resize', () => {
            this.resizeCanvas();
        });
    }
    
    resizeCanvas() {
        if (!this.canvas || !this.container) return;
        
        const oldWidth = this.canvas.width;
        const oldHeight = this.canvas.height;
        
        this.canvas.width = this.container.clientWidth;
        this.canvas.height = 500;
        
        // Redraw if we had content
        if (this.nodes.length > 0) {
            this.render();
        }
    }
    
    renderGraph(graphData) {
        this.nodes = [];
        this.edges = [];
        this.gridSize = graphData.rows;
        
        // Calculate grid dimensions
        const cellWidth = this.canvas.width / (graphData.cols + 2);
        const cellHeight = this.canvas.height / (graphData.rows + 2);
        this.nodeRadius = Math.min(cellWidth, cellHeight) * 0.35;
        
        // Create node positions
        graphData.grid.forEach((row, rowIndex) => {
            row.forEach((node, colIndex) => {
                const x = (colIndex + 1) * cellWidth;
                const y = (rowIndex + 1) * cellHeight;
                
                this.nodes.push({
                    id: node.id,
                    x,
                    y,
                    type: node.type,
                    row: rowIndex,
                    col: colIndex
                });
            });
        });
        
        // Create edges
        const allEdges = graphData.graph.getAllEdges();
        this.edges = allEdges.map(edge => ({
            from: this.nodes.find(n => n.id === edge.from),
            to: this.nodes.find(n => n.id === edge.to),
            weight: edge.weight
        })).filter(edge => edge.from && edge.to);
        
        this.render();
    }
    
    render() {
        if (!this.ctx || !this.canvas) return;
        
        // Clear canvas
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
        
        // Draw edges first (behind nodes)
        this.drawEdges();
        
        // Draw nodes
        this.nodes.forEach(node => {
            this.drawNode(node);
        });
        
        // Draw node labels
        this.nodes.forEach(node => {
            this.drawNodeLabel(node);
        });
    }
    
    drawEdges() {
        this.ctx.strokeStyle = '#cbd5e1';
        this.ctx.lineWidth = 2;
        
        this.edges.forEach(edge => {
            this.ctx.beginPath();
            this.ctx.moveTo(edge.from.x, edge.from.y);
            this.ctx.lineTo(edge.to.x, edge.to.y);
            this.ctx.stroke();
            
            // Draw weight if not 1
            if (edge.weight !== 1) {
                const midX = (edge.from.x + edge.to.x) / 2;
                const midY = (edge.from.y + edge.to.y) / 2;
                
                this.ctx.fillStyle = '#64748b';
                this.ctx.font = '12px Poppins';
                this.ctx.textAlign = 'center';
                this.ctx.textBaseline = 'middle';
                this.ctx.fillText(edge.weight.toString(), midX, midY);
            }
        });
    }
    
    drawNode(node) {
        // Determine node color based on type
        let color = this.colors.empty;
        let borderColor = '#94a3b8';
        let borderWidth = 2;
        
        switch (node.type) {
            case 'start':
                color = this.colors.start;
                borderColor = '#0da271';
                borderWidth = 3;
                break;
            case 'end':
                color = this.colors.end;
                borderColor = '#dc2626';
                borderWidth = 3;
                break;
            case 'wall':
                color = this.colors.wall;
                borderColor = '#475569';
                break;
            case 'visited':
                color = this.colors.visited;
                borderColor = '#1d4ed8';
                break;
            case 'path':
                color = this.colors.path;
                borderColor = '#d97706';
                break;
        }
        
        // Draw node
        this.ctx.beginPath();
        this.ctx.arc(node.x, node.y, this.nodeRadius, 0, Math.PI * 2);
        this.ctx.fillStyle = color;
        this.ctx.fill();
        
        // Draw border
        this.ctx.strokeStyle = borderColor;
        this.ctx.lineWidth = borderWidth;
        this.ctx.stroke();
        
        // Add glow effect for start/end
        if (node.type === 'start' || node.type === 'end') {
            this.ctx.shadowColor = color;
            this.ctx.shadowBlur = 15;
            this.ctx.beginPath();
            this.ctx.arc(node.x, node.y, this.nodeRadius + 2, 0, Math.PI * 2);
            this.ctx.stroke();
            this.ctx.shadowBlur = 0;
        }
    }
    
    drawNodeLabel(node) {
        this.ctx.fillStyle = this.colors.text;
        this.ctx.font = 'bold 14px Poppins';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.fillText(node.id, node.x, node.y);
        
        // Draw coordinates for debugging
        if (process.env.NODE_ENV === 'development') {
            this.ctx.font = '10px Poppins';
            this.ctx.fillStyle = '#64748b';
            this.ctx.fillText(`${node.row},${node.col}`, node.x, node.y + 20);
        }
    }
    
    updateNode(nodeId, updates) {
        const node = this.nodes.find(n => n.id === nodeId);
        if (node) {
            Object.assign(node, updates);
            this.render();
        }
    }
    
    highlightPath(path) {
        if (!path || !Array.isArray(path)) return;
        
        // Reset all nodes to empty except start/end/wall
        this.nodes.forEach(node => {
            if (node.type !== 'start' && node.type !== 'end' && node.type !== 'wall') {
                node.type = 'empty';
            }
        });
        
        // Mark path nodes
        path.forEach((nodeId, index) => {
            const node = this.nodes.find(n => n.id === nodeId);
            if (node && node.type !== 'start' && node.type !== 'end') {
                node.type = 'path';
                
                // Add animation delay for visual effect
                setTimeout(() => {
                    this.render();
                }, index * 100);
            }
        });
        
        this.render();
    }
    
    animateStep(step) {
        switch (step.type) {
            case 'visit':
                this.updateNode(step.nodeId, { type: 'visited' });
                break;
                
            case 'discover':
                this.updateNode(step.nodeId, { type: 'visited' });
                break;
                
            case 'found':
                this.highlightPath(step.path);
                break;
        }
    }
    
    reset() {
        this.nodes.forEach(node => {
            if (node.type !== 'start' && node.type !== 'end' && node.type !== 'wall') {
                node.type = 'empty';
            }
        });
        this.render();
    }
    
    getNodeAtPosition(x, y) {
        return this.nodes.find(node => {
            const distance = Math.sqrt(
                Math.pow(x - node.x, 2) + Math.pow(y - node.y, 2)
            );
            return distance <= this.nodeRadius;
        });
    }
}

// Initialize visualization system
document.addEventListener('DOMContentLoaded', function() {
    // Initialize graph visualizer
    const graphVisualizer = new GraphVisualizer('graph-container');
    window.graphVisualizer = graphVisualizer;
    
    // Connect algorithm visualizer with graph visualizer
    if (window.algorithmVisualizer && graphVisualizer) {
        algorithmVisualizer.on('onNodeVisit', (step) => {
            graphVisualizer.animateStep(step);
        });
        
        algorithmVisualizer.on('onComplete', () => {
            console.log('Algorithm visualization complete');
        });
    }
    
    // Set up UI controls
    const startBtn = document.getElementById('start-visualization');
    const resetBtn = document.getElementById('reset-visualization');
    const graphSizeSlider = document.getElementById('graph-size');
    const speedSlider = document.getElementById('speed');
    
    if (startBtn) {
        startBtn.addEventListener('click', async () => {
            if (!algorithmVisualizer || !graphVisualizer) return;
            
            startBtn.disabled = true;
            startBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Running...</span>';
            
            // Get current settings
            const size = parseInt(graphSizeSlider.value) || 8;
            const speed = parseInt(speedSlider.value) || 5;
            
            // Update algorithm speed
            algorithmVisualizer.setSpeed(speed);
            
            // Generate new graph
            const graphData = algorithmVisualizer.generateRandomGraph(size);
            
            // Update size display
            const sizeValue = document.getElementById('size-value');
            if (sizeValue) {
                sizeValue.textContent = `${size} nodes`;
            }
            
            // Render graph
            graphVisualizer.renderGraph({
                ...graphData,
                graph: algorithmVisualizer.graph
            });
            
            // Run visualization
            await algorithmVisualizer.visualize(graphData);
            
            // Reset button state
            startBtn.disabled = false;
            startBtn.innerHTML = '<i class="fas fa-play"></i><span>Start Visualization</span>';
        });
    }
    
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            if (algorithmVisualizer) {
                algorithmVisualizer.reset();
            }
            
            if (graphVisualizer) {
                graphVisualizer.reset();
            }
            
            // Reset steps container
            const stepsContainer = document.getElementById('steps-container');
            if (stepsContainer) {
                stepsContainer.innerHTML = '<div class="step">Reset. Ready to visualize...</div>';
            }
        });
    }
    
    if (graphSizeSlider) {
        graphSizeSlider.addEventListener('input', function() {
            const sizeValue = document.getElementById('size-value');
            if (sizeValue) {
                sizeValue.textContent = `${this.value} nodes`;
            }
        });
    }
    
    if (speedSlider) {
        speedSlider.addEventListener('input', function() {
            if (algorithmVisualizer) {
                algorithmVisualizer.setSpeed(this.value);
            }
        });
    }
    
    // Initialize with default values
    if (graphSizeSlider && document.getElementById('size-value')) {
        document.getElementById('size-value').textContent = `${graphSizeSlider.value} nodes`;
    }
    
    if (speedSlider && algorithmVisualizer) {
        algorithmVisualizer.setSpeed(speedSlider.value);
    }
    
    console.log('Graph Visualization system initialized');
});